/-
Prints the axioms each main theorem depends on. `build.sh` fails unless they are among Lean's standard three
(`propext`, `Classical.choice`, `Quot.sound`): no `sorryAx`, no `Lean.ofReduceBool` (which `native_decide` would add).
-/
import SpectreKnot

open SpectreKnot

-- §§3–4: strands (Lemma 3.4), the decoration and the tile's signature (Def 3.1, Lemma 4.4)
#print axioms StrandSystem.closed_or_path
#print axioms tileBox_proper
#print axioms tile_signature
-- §5: the zigzag lemma (Lemma 5.1)
#print axioms Zigzag.zigzag
-- §5: Prop 5.4, for every well-formed gluing
#print axioms Gluing.prop_5_4_a
#print axioms Gluing.prop_5_4_b
#print axioms Gluing.prop_5_4_c
#print axioms Gluing.fullReach_unique
-- §6: side lengths (Prop 6.1, Prop 6.2, Cor 6.3, Lemma 6.4, Lemma 6.5)
#print axioms sideLen_eq_letterLen
#print axioms letterLen_fib
#print axioms letterLen_parity
#print axioms sideLen_parity
#print axioms dOff_fib
#print axioms bounds
-- §7: the skeleton walks of Remark 7.8 in the kernel, agreement with the JavaScript walk, negative control
#print axioms Skeletons.skeleton_walks
#print axioms Skeletons.agrees_with_js
#print axioms Skeletons.negative_control
-- §7: Computation 7.3, the 18 compositions at the level-1 lengths, from the tables alone; negative control
#print axioms Compose.compositions_level1
#print axioms Compose.compositions_level1_signature
#print axioms Compose.negative_control
-- §7: the lengthening lemma (Lemma 7.1) and Prop 7.4 (compositions at every level: Computation 7.3 at every level m ≥ 1)
#print axioms Gluing.Cut.OK.sim
#print axioms Gluing.Cut.OK.sig
#print axioms Gluing.Equiv.sig
#print axioms Compose.Move.OK.equiv
#print axioms Compose.sig_base
#print axioms Compose.parity_lemma
#print axioms Compose.parity_lemma_adj
-- Theorem A (the statement file's `TheoremA`): Thm 7.6 at tile level, by induction from the level-1 clusters
#print axioms Statement.good_one
#print axioms Statement.Kids.follow_of_reach
#print axioms Statement.Kids.noClosed
#print axioms Statement.Kids.parent_sig
#print axioms Statement.own_rot
#print axioms Statement.good
#print axioms Statement.theoremA
#print axioms Statement.loopPatch_closed
-- Theorem B (the statement file's `TheoremB`, `TheoremB_sharp`): the junction map (Computation 8.6, Lemma 8.7) at every
-- level, then the nest
#print axioms Statement.step_base
#print axioms Statement.StepOK.move
#print axioms Compose.adm_induct
#print axioms Statement.step_level
#print axioms Statement.super_glueSymm
#print axioms Statement.linked_symm
#print axioms Statement.step_tile
#print axioms Statement.stretch_eq
#print axioms Statement.chain_even
#print axioms Statement.chain_odd
#print axioms Statement.no_boundary
#print axioms Statement.theoremB_sharp
#print axioms Statement.theoremB
-- Theorem B, final form (the statement file's `NestModel`, `TheoremB_strand`): the nest tiling as one patch, and
-- Lemma 3.4 applied to it
#print axioms Statement.super_noSelf
#print axioms Statement.nestModel
#print axioms Statement.not_closed
#print axioms Statement.all_same
#print axioms Statement.theoremB_strand
-- Theorem A in strand form (the statement file's `ChainModel`, `TheoremA_strand`): the union of any chain of
-- supertiles that covers the plane, and Lemma 3.4 applied to it
#print axioms Statement.chainModel
#print axioms Statement.Chain.all_glued_at
#print axioms Statement.Chain.not_closed
#print axioms Statement.theoremA_strand
