# Lean formalisation

A formalisation of the proof of *The Spectre Knot* (the paper's PDF is published with these files; in the development repository it is `../paper/spectre_knot.pdf`) in Lean 4, **without Mathlib**. It
proves Prop 5.4 (reduced composition) for every well-formed gluing; that the compositions of level-m supertiles have
the signature at every level m ≥ 1, by lengthening (`Compose.parity_lemma`, the paper's Prop 7.4); that every
supertile of level m ≥ 1 has the signature (the paper's Thm 7.6, the Signature Theorem), so that none contains a closed strand
(`Statement.theoremA`); the paper's **Ariadne Theorem**: in the nest the strands of every block join within three or
four levels (`Statement.theoremB`, `Statement.theoremB_sharp`), and the ribbons of the nest tiling form one two-way
infinite strand (`Statement.theoremB_strand`); and the paper's **Endless Strand Theorem** for tilings whose hierarchy
covers the plane, in the form: in the union of any chain of supertiles in which every edge is eventually glued, every
strand is a two-way infinite path (`Statement.theoremA_strand`). The case of the Endless Strand Theorem for tilings with
a fault (the paper's Lemmas 7.10-7.12) is not formalised. Written by the AI system (Claude) at the owner's direction,
like everything else in this repository.

The paper's proofs of the signature (§7) and of the merging (§8.2) take the routes this formalisation takes; see
*How the formal proof relates to the paper* below.

## The statement file: start here

**`SpectreKnot/Statement.lean` is the file to read.** It holds every definition the main theorems use, and the
theorems themselves as claims, with a comment on every line in plain English and a short guide to reading Lean:

- §5: `TheoremA` (no supertile contains a closed strand), `TheoremB` (the nest has no boundary, no closed strand, and
  any two ports of a block lie on one strand of a larger block) and `TheoremB_sharp` (the paper's bound: three levels
  up for even b, four for odd b);
- §6: the nest tiling as one patch (`nestTiling`), `NestModel` (it is a tiling, and it contains every block) and
  `TheoremB_strand` (its ribbons form one two-way infinite strand through every port);
- §7: any chain of supertiles X₁ ⊂ X₂ ⊂ ⋯, each a child of the next (`Chain`); `ChainModel` (the union of the chain is
  a tiling containing every block, and, if every edge is eventually glued, a tiling with no boundary) and
  `TheoremA_strand` (in that case every strand of the union is a two-way infinite path: the paper's Endless Strand
  Theorem, for tilings whose hierarchy covers the plane).

The claims are combinatorial, about patches of tiles described by which edges are glued. The link to real tilings is
one assumption, (M), written out at the top of the file and not formalised: real supertiles are glued like the ones
the file builds. Every claim is proved, and Lean's kernel has checked each proof against exactly this statement:
`theoremA` in `SpectreKnot/ProofA.lean`; `theoremB` and `theoremB_sharp` in `SpectreKnot/ProofB.lean`; `nestModel`
and `theoremB_strand` in `SpectreKnot/ProofStrand.lean`; `chainModel` and `theoremA_strand` in
`SpectreKnot/ProofChain.lean`.

How the statement's definitions are tested (`Tests.lean`; `TestsSlow.lean` with `./build.sh --slow`):

- the level-2 supertiles it builds from the tables equal, edge for edge, those built from the tile placements in
  exact arithmetic (`Data/Level2.lean`, from `exact.py`), with the same six vertices; the level-1 sides have the
  lengths ℓ₁ of Prop 6.1 (`Pattern.len1`);
- sizes: tiles 9, 71, 559, 4,401 and rims 46, 182, 758, 3,198 for Δ, and rims 44, 160, 652 (as in the paper) and
  2,736 for Γ;
- the paper's Table 5 comes out of its definitions of "following a ribbon" and "the nest": N₀'s pieces lie on 5, 2, 1
  strands of N₁, N₂, N₃; N₁'s on 10, 2, 2 (and 1 in N₅, slow); N₂'s on 37, 2 (and 1 in N₅, slow);
- negative control: along the chain of the paper's Remark 9.1 the same definitions give 32, 3, 3 (and 3 in X₅,
  slow) strands, not one. So "one strand" is not built into the definitions;
- negative control for `TheoremA` (a theorem, `loopPatch_closed`): a one-tile patch with a made-up gluing that traps a
  ribbon fails `NoClosedStrand`. So "no closed strand" is not built into the definitions either.

`Tests.lean` also checks the 18 compositions of Computation 7.3 at levels 1 and 2: they are well formed; the full and
the reduced walk agree from every port; at level 1 the runs number 52 (45 for Γ); the rims of the level-2 Γ and Δ have
160 and 182 edges; the base checkers hold and reject a wrong sign and non-adjacent corners. `TestsSlow.lean` also
computes the conclusion of Prop 7.4 at level 2 directly. Tests are `#guard`s, not proofs, but the build fails if one
fails.

## How the formal proof relates to the paper

The formal proofs follow the paper's §§3–8: the signature at every level by lengthening (Lemmas 7.1 and 7.2,
Computation 7.3, Prop 7.4, Thm 7.6), the Endless Strand Theorem for tilings whose hierarchy covers the plane by the
covering argument at the start of §7.4, and the merging by the junction map (Computation 8.6, Lemmas 8.7 and 8.8, the proof of Thm 8.5). The differences are of
detail:

- **Strands** are modelled as two fixed-point-free involutions on ports (`inside`, `across`), not as the strand graph
  of Def 3.3; Lemma 3.4 is stated for them (`StrandSystem.closed_or_path`).
- **Supertiles** are patches described by which edge of which tile is glued to which edge of which other tile, built
  from the tables by `compose` (Prop 2.4 read as a construction) on top of the nine level-1 supertiles, which are data.
  The paper's compositions C_T(L, d, ω) are `Comp.ofLens T L d ω`, gluings of boxes (`Gluing`).
- **Prop 5.4** (b) is proved from every port, not only from reduced ports; (c) is proved in the form used: if the walk
  from every port at a mark reaches the rim, there is no closed strand.
- **Lemma 7.1** (lengthening) is proved in two steps: cutting an edge into three maps every walk to a walk with the same
  ends (`Gluing.Cut.OK.sim`), and lengthening a pair of glued sides by two edges *is* cutting one of their edges
  (`Compose.Move.OK.equiv`). That a move creates no closed strand goes through Prop 5.4 (b), (c) (`Sim.noLoops`: the
  marks after the cut are images of marks before it); the paper argues directly with the zigzag lemma.
- **Lemma 7.2** (reachability) is the induction `Compose.adm_sig` (and `adm_induct` for any property), backwards on
  the excess over the level-1 lengths. `adm_induct` makes the paper's choice of move (the third edge of a side; on the
  Σ child's side 5 the second edge before or after the corner); `adm_sig`, used for the signature, cuts the second edge
  of an ordinary side, which is also a move.
- **Lemma 8.3** is used in form (b), that every edge of N_b is glued in N_{b+2} (`no_boundary`), proved from the tables
  as the paper notes; form (a), about points of the plane, is not formalised.
- **Lemma 8.8** is proved with "at least two edges from the ends", which is what the proof needs; the paper states
  five.
- **The Endless Strand Theorem** is proved for any chain of supertiles whose union has every edge eventually glued
  (`TheoremA_strand`); that a tiling whose hierarchy covers the plane is such a union is part of (M). The case of a
  tiling with a fault (the paper's Def 7.9, Lemmas 7.10-7.12 and the rest of §7.4) is not formalised.
- **Thm 8.5** is proved as the bound (`TheoremB_sharp`); the exact counts in the last two rows of Table 5 are not
  formalised.

## Building

```
./build.sh          # about 6 minutes from clean (peak memory about 1.5 GB per kernel check); seconds when cached
./build.sh --data   # first regenerate the data files from paper/code (python3, node)
./build.sh --slow   # also run TestsSlow.lean (level-5 checks, about 2 minutes more)
```

`build.sh` fails if any source uses `sorry`, `admit` or `native_decide` outside comments (`tools/no_sorry.py`), if a
`theorem` or a `have` lacks a comment (`tools/check_comments.py`), if the build or a test fails, or if any theorem
listed in `Axioms.lean` depends on an axiom other than Lean's standard three (`propext`, `Classical.choice`,
`Quot.sound`). From clean, most of the time goes on the kernel computations: `CompFull` (the 18 compositions of
Computation 7.3, about 2.5 minutes), `Tests` (about 1.5 minutes), `SigCheck` and `SkeletonWalks` (about 30 s each),
then the level-1 checks (`PatchSig`, a few seconds) and the junction map (`StepMap`, a few seconds).

Toolchain: Lean 4.34.1 (pinned in `lean-toolchain`), core library only. In a claude.ai cloud container, elan cannot
resolve a toolchain because `release.lean-lang.org` is blocked, but GitHub release downloads work:

```
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y --default-toolchain none
curl -sSL -o lean.tar.zst https://github.com/leanprover/lean4/releases/download/v4.34.1/lean-4.34.1-linux.tar.zst
# unpack (tar --zstd, or python3 -m pip install zstandard), then:
mv lean-4.34.1-linux ~/.elan/toolchains/leanprover--lean4---v4.34.1
```

## What is formalised

Numbering as in the paper.

| paper | Lean | kind | what the Lean statement says |
|---|---|---|---|
| Lemma 3.4 | `StrandSystem.closed_or_path` | proof | Strands are modelled as two fixed-point-free involutions on ports: `inside` (the pieces) and `across` (the straight-through rule). A strand is either closed, or a two-way infinite path that never passes a port or a piece twice. |
| Def 3.1, Lemma 4.4 (tile) | `tilePiece`, `tile_signature` | `decide` | A separate model of the tile: its 14 pieces as a pairing of its 28 ports, and the tile has the signature at (v₀, v₁). (The statement file has its own decoration, `pieceEnd`; the main theorems use that one.) |
| Lemma 5.1 | `Zigzag.zigzag` | proof, any `n` | Along a shared path of `n` edges, the two connections and where each hook goes, exactly as in the paper. Its core, `Zigzag.walk_core`, is what Prop 5.4 and the lengthening use. |
| Lemma 4.2, Def 5.2 | `Gluing`, `FullReach`, `smooth`, `runLen`, `sigmaRed`, `RedReach` | definitions | A patch glued from children that each have the signature, in general (`Gluing`): the full walk of Lemma 4.2 as an inductive relation; marks (non-smooth vertices: junctions and corners on either side); runs; the reduced walk. |
| Prop 5.4(a) | `Gluing.prop_5_4_a` | proof | A child's vertex that is not a mark, with both edges on the parent's rim, is a hook of the parent. |
| Prop 5.4(b) | `Gluing.prop_5_4_b`, `Gluing.fullReach_unique` | proof | For every well-formed gluing and every port: the full walk and the reduced walk end at the same rim port; and the end of the full walk is unique. |
| Prop 5.4(c), the form used | `Gluing.prop_5_4_c` | proof | If the reduced walk from every port at a mark reaches the rim, so does the full walk from every port: no closed strand. |
| Prop 6.1 | `sideLen_eq_letterLen` | proof + `decide` on Tables 1, 3, 4 | ℓ_m(K, j) depends only on the letter, for every m ≥ 1. Here ℓ_m is *defined* by the recursion of Prop 2.4(c) from the level-1 counts. |
| Prop 6.2 | `letterLen_fib` | proof | The Fibonacci closed forms. |
| Cor 6.3 | `letterLen_parity`, `sideLen_parity` | proof | Parities are the same at every level ≥ 1 (for the letters, and for the sides). |
| Lemma 6.4 | `dOff_fib` | proof | d_m = 2F_{3m+1}, and δ_m − d_m = 2F_{3m}. Here d_m is defined from Table 3 (the pieces 0.2, 0.1, 7.0). |
| Lemma 6.5 | `bounds` | proof | Every side ≥ 5, d_m ≥ 6, δ_m − d_m ≥ 4. (The rest of the lemma, that β_m is the shortest side, d_m ≥ β_m, and δ_m − d_m ≥ β_m for m ≥ 2, is used only for Lemma 7.12 and is not formalised.) |
| §7.1, the compositions | `Compose.Comp.ofLens`, `Comp.toGluing`, `Comp.check` | definitions | C_T(L, d, ω) built from Tables 1–3, side by side: children with the signature at their corners (A at vertex 0, or for Σ at distance d along side 5; B = A + ω), sides glued in pairs reversing direction, the parent's rim from Table 3. |
| Lemma 7.1 (lengthening) | `Gluing.Cut.OK.sim`, `Gluing.Cut.OK.sig`, `Compose.Move.OK.equiv`, `Compose.Move.OK.keep` | proof | Cutting one edge into three (shared by two children, or on the parent's rim) maps every walk to a walk with the same ends, and keeps the signature; "no closed strand" carries over by Prop 5.4 (c) and (b) (`Sim.noLoops`). Lengthening a glued pair of sides by two edges (and d by two if the cut lies before the Σ corner) gives the same gluing, port for port, as cutting one edge; so a move keeps the signature. |
| Lemma 7.2 (reachability) | `Compose.Adm`, `Compose.adm_level`, `Compose.adm_sig`, `Compose.adm_induct` | proof | The admissible pairs (L, d) are those of the paper; (ℓ_m, d_m) is admissible for every m ≥ 1 (`adm_level`); every admissible pair other than (ℓ₁, d₁) comes by a move from one with less excess, with the paper's choice of move in `adm_induct` (the third edge of a side; on the Σ child's side 5 the second edge before the corner, or the second after it; `adm_sig` cuts the second edge of an ordinary side instead); so a property that holds at (ℓ₁, d₁) and survives such moves holds at every admissible pair (`adm_induct`). |
| Comp 7.3 | `Compose.compositions_level1`, `Compose.compositions_level1_signature`, `Compose.sig_base` | kernel computation + proof | The 18 compositions C_T(ℓ₁, d₁, ±1), built from Tables 1–4 and ℓ₁, d₁, glued port by port (Lemma 4.2). For each, the checker `Comp.check` returns `true`, and `Comp.check_sound` turns that into statements: the walk from every port ends on the rim, every parent rim vertex but the Γ child's corners is a hook, and the corners are adjacent and carry the crossover. `sig_base` states the same as `Gluing.Sig` (each parent rim vertex found by turning about a child's vertex, `Gluing.Rot`), the form the induction carries. |
| Prop 7.4 | `Compose.parity_lemma`, `Compose.parity_lemma_adj` | proof + kernel computation | For every m ≥ 1, every kind and both signs: C_T(ℓ_m, d_m, ω) is well formed and has the signature (`Gluing.Sig`): no strand closes up; every parent rim vertex is a hook except the Γ child's corners A and B; A and B lie on the parent's rim and carry the crossover (`parity_lemma`), and are adjacent, B after A in the children's sense if ω, before it otherwise (`parity_lemma_adj`). |
| Comp 7.5 | `Statement.good_one` | kernel computation | The nine level-1 supertiles (from `exact.py`) have the signature, with A and B where the induction expects them. |
| §7.1 (a supertile is its composition), with Lemma 4.2 | `Statement.Kids.follow_of_reach`, `Statement.Kids.noClosed`, `Statement.glue_rim` | proof | In `compose T child`, if the children have the signature with the corners and side lengths of `Comp.ofLens`: across a child's rim edge, `compose` glues exactly what `Comp.mate` says; every walk of the composition is a strand of the parent; and the parent has no closed strand when the composition has none. |
| §7.1 (v): the rim of `compose` (Tables 2 and 3 agree) | `Statement.rim_edgeAt`, `Statement.own_rot`, `Statement.parent_vtx` | proof + table check | The parent's rim, read from Table 3, is the rim of the glued children: its positions are the children's unglued edges, each once; consecutive positions meet at a parent rim vertex (turning about it by Table 2: `rimTablesOk`); its six vertices are where the parent's side lengths put them. |
| Thm 7.6 (Signature Theorem) | `Statement.good`, `Statement.Kids.parent_sig`, `Statement.theoremA` | proof + kernel computation | Every supertile `super m K` of level m ≥ 1 has the signature at tile level (`Patch.HasSig`): its rim list is exactly its unglued edges, each once; no strand closes; following the ribbon from each rim port leads to the other port at the same rim vertex, except at the corners A and B (vertex 0, or for Σ the point d_m along side 5, with B next to A), which cross over (`corners_nonSigma`, `corners_sigma`). Hence `TheoremA`: no supertile of any level or kind contains a closed strand. |
| **Endless Strand Theorem**, where the hierarchy covers the plane (start of §7.4) | `Statement.chainModel`, `Statement.theoremA_strand` | proof | For any chain of supertiles, each a child of the next: its union, with its tiles numbered so that every block keeps its own numbering, is a tiling containing every block (`ChainModel`; a gluing that contains every block exists, chosen with `Classical.choice`). If every edge is eventually glued, every such gluing glues every edge, and every strand of the union is a two-way infinite path (`TheoremA_strand`): a closed strand would visit finitely many tiles, whose edges are all glued in one block (`all_glued_at`), and that block has no closed strand. |
| Comp 8.6 | `Statement.step_base` | kernel computation | In C_Δ(ℓ₁, d₁, ±1), the walk from every port of child 1 outside its side 2 ends at a port of the parent hook at the junction that `tgt` names (the paper's Table 6). |
| Lemma 8.7 | `Statement.step_level`, `Statement.StepOK.move`, `Statement.step_tile`, `Statement.stretch_eq` | proof | The same at the level-m lengths, every m ≥ 1, both signs: carried from ℓ₁ by the moves of Lemma 7.2 (`adm_induct`), with cuts on child 1 kept two edges from the ends of its sides; a cut adds two vertices whose strands are those of the old vertices next to it (`NewWalk.lean`). At tile level: a rim port of N_m lies, in N_{m+1}, on the strand of the hook at that junction; strictly inside N_m's side 2 the rim port is a hook of N_{m+1} itself. |
| Lemma 8.8 | `Statement.inside_9`, `inside_12`, `inside_16`, `inside_17`, `inside_21`, `inside_stp` | proof | The junctions 9, 12, 16, 17, 21 lie inside sides 2, 3, 4, 4, 5 of N_{m+1}, and the inside of N_m's side 2 inside side 4, at least two edges from the ends. |
| Lemma 8.3(b) (Grandparent Lemma) | `Statement.no_boundary` | proof | Every edge of N_b (b ≥ 1) is glued in N_{b+2}. |
| — | `Statement.super_glueSymm`, `Statement.linked_symm`, `Statement.super_noSelf` | proof + kernel computation | Every supertile's gluing is symmetric, and glues no tile to itself (the level-1 data checked by the kernel); so "same strand" (`Linked`) is symmetric there. |
| Thm 8.5, then the **Ariadne Theorem** (combinatorial form, the statement file's `TheoremB`) | `Statement.chain_even`, `Statement.chain_odd`, `Statement.theoremB_sharp`, `Statement.theoremB` | proof | Every port of N_b lies, in N_{b+3} (b even) or N_{b+4} (b odd), on the strand of the hook at junction 12; with symmetry, any two ports of N_b are on one strand there (`TheoremB_sharp`). With `no_boundary` and `TheoremA`, `TheoremB`. |
| **Ariadne Theorem**, final form | `Statement.nestModel`, `Statement.theoremB_strand` | proof + kernel computation | The nest tiling as one patch (`nestTiling`): its tiles numbered so that every block keeps its own numbering, and a gluing that contains every block's and glues every edge, to an edge of another tile, which is glued back (`NestModel`). Its ports form a `StrandSystem`. No strand is closed, since a closed strand would stay in one block, which has none (Theorem A); any two ports lie on one strand, since they do in a large enough block (`TheoremB_sharp`). So by Lemma 3.4 the strand through R(v₀) of the original tile is two-way infinite, never meets a port or a piece twice, and runs through every port (`TheoremB_strand`). |
| Remark 7.8 (corroboration) | `Skeletons.skeleton_walks`, `Skeletons.agrees_with_js` | kernel computation | A corroborating check: the reduced walk on the 18 skeletons exported from `synth.js` gives the signature, and finds the same non-hooks as `core/reduce.js`. Not used by the main results. |
| — | `Skeletons.negative_control`, `Compose.negative_control`, `Statement.loopPatch_closed` | kernel computation / proof | Corrupted inputs are rejected, so the checks and the definitions are not vacuous. |

Data: `SpectreKnot/Data/Pattern.lean` (Tables 1–4, the level-1 side lengths, d₁) is generated from
`paper/code/hierarchy/combin_8.json` and `letters.json` by `tools/gen_pattern.py`. `Data/Clusters.lean` (the nine
level-1 supertiles at tile level) and `Data/Level2.lean` (level 2, for tests) are computed by `tools/gen_clusters.py`
with `paper/code/exact/exact.py` (exact arithmetic). `Data/Skeletons.lean` (for the skeleton check) is generated from
`synth.js` by `tools/gen_skeletons.js`. The two computations on compositions (Computation 7.3 and Computation 8.6) are
also done, separately, by `paper/code/hierarchy/compositions.py`.

## What the main results use

`tools/unused.lean` (run `lake env lean tools/unused.lean`) lists every declaration that the seven main results
(`theoremA`, `theoremB`, `theoremB_sharp`, `nestModel`, `theoremB_strand`, `chainModel`, `theoremA_strand`) do not
use. Everything else in `SpectreKnot/` is used by them, including Prop 5.4 (b), (c) and the zigzag lemma's core. What
they do not use is kept on purpose:

| not used by the main results | why it is kept |
|---|---|
| `Box.lean` (`tilePiece`, `tileBox`, `tile_signature`, …) | A separate model of the tile (Def 3.1, Lemma 4.4); the statement file has its own decoration. |
| `Skeleton.lean`, `SkeletonWalks.lean`, `Data/Skeletons.lean` | A run of the skeleton walks (Remark 7.8) on skeletons exported from JavaScript, and its agreement with `core/reduce.js`: corroboration. |
| `Zigzag.zigzag`, `Gluing.prop_5_4_a` (with `smooth_corner`), `Gluing.fullReach_unique`, `sideLen_parity`, `Compose.parity_lemma_adj` (with `sig_adj`, `ofLens_B'`), `Compose.compositions_level1_signature` | Results of the paper, formalised as stated there; the main proofs use other forms of them (`walk_core`, `letterLen_parity`, `parity_lemma`, `compositions_level1`). |
| `Skeletons.negative_control`, `Compose.negative_control` (with `spreadCorners`), `Statement.loopPatch_closed` | Negative controls: the checks and the definitions are not vacuous. |
| `Compose.allKinds`, `Gluing.redWalk`, `Gluing.redWalk_sound` | Used by the tests. |

The tool has one blind spot: a `@[simp]` lemma proved by `rfl` leaves no trace in the proofs that use it. It lists
`iter_zero`, which `iter_add` uses that way.

## What it does not show

- **The link with tilings of the plane: assumption (M).** The formal statements are about patches described by their
  gluing. That the supertiles of an actual tiling are glued like `super m K` is assumption (M) (`Statement.lean`). It
  rests on the spectre paper and on the paper's §2, none of which is formalised: Thm 2.1 (the hierarchy, from the
  spectre paper), Prop 2.4 (the composition pattern holds at every level), Remark 2.5 (its cross-checks against the
  spectre paper's figures), Lemma 2.6 (rigidity) and Def 2.2 (own orientation, built into `compose`). In Lean,
  Tables 1–4 are simply data.
- **The Endless Strand Theorem for tilings.** `TheoremA_strand` is about the union of a chain of supertiles in which
  every edge is eventually glued. That a tiling whose hierarchy covers the plane is such a union (the argument about
  points of the plane at the start of §7.4) is part of (M). Tilings with a fault (Def 7.9, Lemmas 7.10-7.12, and the
  proof of the Endless Strand Theorem at the end of §7.4) are not formalised.
- **The Ariadne Theorem for the nest tiling of the plane.** `TheoremB_strand` is about `nestTiling`, the union of the blocks
  `super b .Delta`. That this is the nest tiling of the paper, and that it covers the plane, is Prop 8.2, Lemma 8.3(a)
  and Prop 8.4, which are geometric and not formalised.
- **Level 0 of the hierarchy.** The Lean starts from the nine level-1 supertiles as data. The Mystic (the level-0 Γ,
  Lemma 4.4) is inside them and is not treated separately.
- **The skeleton route.** Def 5.3 (skeletons and their equality), Cor 5.5 (where a hook goes) and the skeleton argument
  of Remark 7.8 (3) are not formalised (the skeleton walks are computed, not used). Nor are the label states
  and certificates of Remark 8.9 (3).
- **Exact counts.** Thm 8.5 is formalised as the bound; the numbers of Table 5 are computed by the tests for small b,
  not proved for every b.
- **Remarks and the drawing.** Remark 3.5 (no single strand in a periodic tiling), Remark 3.6 (over and under), the
  drawing itself, Remark 9.1 (three strands along another chain; the tests compute its first counts) and the rest of
  §9.
- **Data are input.** Tables 1–3 come from `combin.js` (the composition pattern computed from the geometry, and checked
  against the spectre paper's figures by the paper's scripts) and Table 4 from `letters.py` (`letters.json`); the level-1 supertiles come from `exact.py`. The Lean
  checks the level-1 supertiles' signature itself (`good_one`), but not that they are the spectre paper's clusters.

## Assessment

The seven main results are proved in the combinatorial form of the statement file, checked by Lean's kernel against
`TheoremA`, `TheoremB`, `TheoremB_sharp`, `NestModel`, `TheoremB_strand`, `ChainModel` and `TheoremA_strand` as
written there: no supertile contains a closed strand (`TheoremA`, the last sentence of Thm 7.6; the signature itself,
for every level m ≥ 1, is `Statement.good`, proved on the way), the Ariadne Theorem, and the Endless
Strand Theorem for tilings whose hierarchy covers the plane. What stands between them and the paper's theorems is
assumption (M), with the geometric facts about the plane listed above, all stated in `Statement.lean`; and, for the
Endless Strand Theorem in tilings with a fault, the argument of the paper's §7.4 (Lemmas 7.10-7.12), which is not
formalised.
