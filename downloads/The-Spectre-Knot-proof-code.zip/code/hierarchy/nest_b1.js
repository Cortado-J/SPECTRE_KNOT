// Theorem "Merging", b = 1, as a corroboration (the proof covers b = 1 by the symbolic run of hierarchy/certnest.js,
// odd parity): the label computation of Section 8 (Definition "Label state", steps (S1)-(S4), Lemma "step") for the
// nest N_1 < N_2 < ... < N_5, on the skeletons S_Delta(l_m, d_m, omega_m) built from the composition pattern and the
// actual side lengths (hierarchy/chains_label.js), with exact integer positions. No geometry is used.
// usage: node hierarchy/nest_b1.js
process.argv.length = 2;
const { runChain } = require('./chains_label.js');
const rows = runChain(1, 'Delta', [['Delta', 1], ['Delta', 1], ['Delta', 1], ['Delta', 1]]);
let ok = true;
for (const r of rows) {
  console.log(`  N_${r.N}: the 46 arcs of N_1 lie on ${r.blocks} arcs (${r.classes} label classes + ${r.stretchV} stretch vertices); ` +
    `closed strands ${r.loops}, lost labels ${r.lost}; one kept label per class, non-hook parent marks A+ and B+: ${r.bookkeeping ? 'yes' : 'NO'}`);
  if (r.loops || r.lost || !r.bookkeeping) ok = false;
}
const want = [10, 2, 2, 1];   // Table "merge", row b = 1 (also found by exact strand following, exact/exact.py)
if (rows.map((r) => r.blocks).join() !== want.join()) ok = false;
console.log(ok ? 'b = 1: P_4(1) HAS A SINGLE PART (counts 10, 2, 2, 1 as in Table "merge")' : 'b = 1: FAILED');
process.exit(ok ? 0 : 1);
