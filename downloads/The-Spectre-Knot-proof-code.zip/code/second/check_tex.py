#!/usr/bin/env python3
"""Compare the tables transcribed in nest2.py with the paper's LaTeX source (../tex/spectre_knot.tex, two folders up
from here in the development repository). Skipped when the source is not present, as in the published code folder."""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
TEX = os.path.join(HERE, '..', '..', 'tex', 'spectre_knot.tex')
if not os.path.exists(TEX): print('paper source not present: skipped'); sys.exit(0)
import nest2 as N
tex = open(TEX).read()
G = {'\\Gamma': 'Γ', '\\Delta': 'Δ', '\\Theta': 'Θ', '\\Lambda': 'Λ', '\\Xi': 'Ξ', '\\Pi': 'Π', '\\Sigma': 'Σ', '\\Phi': 'Φ', '\\Psi': 'Ψ'}
GL = {'\\alpha': 'α', '\\beta': 'β', '\\gamma': 'γ', '\\delta': 'δ', '\\epsilon': 'ε', '\\zeta': 'ζ', '\\eta': 'η', '\\theta': 'θ'}
bad = []
def rows(blk):
    for line in blk.splitlines():
        m = re.match(r'\s*\$(\\[A-Za-z]+)\$ &(.*)\\\\', line)
        if m and m.group(1) in G: yield G[m.group(1)], [x.strip().strip('$') for x in m.group(2).split('&')]
blk = tex[tex.index('parent $T$ & 0 & 1'):tex.index('\\label{tab:children}')]
for T, xs in rows(blk):
    if [G[x] for x in xs if x] != N.CHILDREN[T]: bad.append(('children', T))
blk = tex[tex.index('child & side 0'):tex.index('\\label{tab:sides}')]
for tab, want in zip(blk.split('\\end{tabular}')[:2], (N.SIDES8, N.SIDESG)):
    got = [' '.join('r' if 'rim' in x else x.strip() for x in m.group(1).split('&'))
           for m in re.finditer(r'^\s*\d & (.*)\\\\', tab, re.M)]
    if got != want: bad.append(('sides', got))
blk = tex[tex.index('kind & side 0 & side 1'):tex.index('\\label{tab:letters}')]
for T, xs in rows(blk):
    L = [GL[re.match(r'\\[a-z]+', x).group(0)] + ('+' if '^+' in x else '-' if '^-' in x else '') for x in xs]
    if L != N.LETTERS[T]: bad.append(('letters', T, L))
blk = tex[tex.index('\\emph{Eight children}'):tex.index('\\label{tab:psides}')]
pc = [x.replace(' ', '').split('&') for x in re.findall(r'segment &([^\\]*)\\\\', blk)]
if ' '.join(pc[0] + pc[1]) != N.PIECES8 or ' '.join(pc[2] + pc[3]) != N.PIECESG: bad.append(('pieces',))
for line in blk.splitlines():
    m = re.match(r'\s*\$(\\[A-Za-z]+)\$ & ([\d &]+)\\\\', line)
    if m and m.group(1) in G and tuple(int(x) for x in m.group(2).split('&')) != N.FIRST[G[m.group(1)]]: bad.append(('first', m.group(1)))
gm = re.search(r'sides \$0,\\dots,5\$ begin at positions \$([\d,]+)\$', blk)
if tuple(int(x) for x in gm.group(1).split(',')) != N.FIRST['Γ']: bad.append(('first', 'Γ'))
print('mismatches:', bad) if bad else print('THE TABLES IN nest2.py MATCH THE PAPER SOURCE')
sys.exit(1 if bad else 0)
