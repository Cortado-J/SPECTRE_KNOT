#!/usr/bin/env python3
"""The paper's Tables 1-4 (as transcribed in nest2.py, which second/check_tex.py compares with the paper's source)
against the composition patterns extracted in exact arithmetic from the built supertiles by exact/exact.py
(exact/exact_C.json, written by step A13): children's kinds (Table 1), side adjacency (Table 2), the parent's sides
as concatenations of children's sides and the position of its crossover corner (Table 3), and the side lengths at
levels 1-4 by letter (Table 4 with Prop. "Lengths by letter" and "Fibonacci side lengths"; d_m of Lemma "Position of A").
Also checks that the side labels and letters that hierarchy/certnest.js reads (hierarchy/letters.json) are those of Table 4."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import nest2 as N
J = json.load(open(os.path.join(HERE, '..', 'exact', 'exact_C.json')))
NAMES = ['Gamma', 'Delta', 'Theta', 'Lambda', 'Xi', 'Pi', 'Sigma', 'Phi', 'Psi']
GR = dict(zip(NAMES, N.KINDS))
bad = []
def fib(n):
    a, b = 0, 1
    for _ in range(n): a, b = b, a + b
    return a
for m, ST in sorted(J['ST'].items()):
    for T in NAMES:
        S, t = ST[T], GR[T]
        if [GR[k] for k in S['kids']] != N.CHILDREN[t]: bad.append((m, T, 'Table 1'))
        want = [[None if x is None else '%d.%d' % x for x in row] for row in N.ADJ[t]]
        got = [[None if x == 'R' else x for x in row] for row in S['sides']]
        if got != want: bad.append((m, T, 'Table 2'))
        F, P = N.FIRST[t], ['%d.%d' % x for x in N.PIECES[t]]
        psides = [[P[i % len(P)] for i in range(F[J], F[(J + 1) % 6] + (len(P) if J == 5 else 0))] for J in range(6)]
        if S['pside'] != psides: bad.append((m, T, 'Table 3'))
        if (S['pdef']['side'], S['pdef']['off'] == 0) != ((5, False) if T == 'Sigma' else (0, True)): bad.append((m, T, 'parent A'))
    print(f'composition pattern C_{m} ({m} -> {int(m) + 1}): Tables 1-3 ' + ('match' if not [b for b in bad if b[0] == m] else 'DIFFER'))
lam = list(N.LAM1)
for m in range(1, 5):
    L = J['LEN'][str(m)]
    for T in NAMES:
        if [lam[N.letter(GR[T], j)] for j in range(6)] != L[T]: bad.append((m, T, 'lengths'))
    F = lambda n: fib(n)
    closed = [F(3*m+2)+2, F(3*m+1)+2, 2*F(3*m+2), 2*F(3*m+2), F(3*m+3), 2*F(3*m+1), 2*F(3*m+2), F(3*m+4)-2]
    if lam != closed: bad.append((m, 'closed forms'))
    d = J['DEF'][str(m)]['Sigma']
    if d != {'side': 5, 'off': 2 * F(3*m+1)}: bad.append((m, 'd_m'))     # distance d_m from vertex 5
    print(f'level {m}: side lengths by letter {lam} = Table 4 with the recurrence and the Fibonacci forms; Sigma A on side 5, offset {d["off"]}')
    lam = [lam[1] + lam[4] + lam[6], lam[0] + lam[4], lam[1] + 2 * lam[4] + lam[6] + lam[7], lam[0] + lam[1] + lam[4] + 2 * lam[7],
           3 * lam[4] + lam[6], lam[0] + lam[4] + lam[7], 4 * lam[4] + lam[6], 4 * lam[4] + lam[6] + lam[7]]
# the side letters that hierarchy/certnest.js reads (hierarchy/letters.json, from the Fig. 4.2 encoding) are Table 4
LJ = json.load(open(os.path.join(HERE, '..', 'hierarchy', 'letters.json')))
GL = {'a': 'α', 'b': 'β', 'g': 'γ', 'd': 'δ', 'e': 'ε', 'z': 'ζ', 'h': 'η', 't': 'θ'}
for T in NAMES:
    if [GL[x[0]] + x[1:] for x in LJ['label'][T]] != N.LETTERS[GR[T]]: bad.append((T, 'letters.json labels differ from Table 4'))
    if [LJ['order'].index(w) for w in LJ['letter'][T]] != [N.letter(GR[T], j) for j in range(6)]: bad.append((T, 'letters.json letters differ from Table 4'))
print('hierarchy/letters.json (read by certnest.js): labels and letters ' + ('= Table 4' if not [b for b in bad if 'letters.json' in str(b)] else 'DIFFER'))
print('THE PAPER\'S TABLES MATCH THE EXACT EXTRACTION' if not bad else 'PROBLEMS: ' + repr(bad))
sys.exit(1 if bad else 0)
