# A second implementation of the merging computation

`nest2.py` repeats, separately, the computation behind Lemma "Uniformity in b" and Theorem "Merging" (Section 8 of
the paper): the label states (S1)-(S4) followed for 4 relative levels, symbolically for every base b >= 1 of each
parity, and the certificates for all b. It was written in Python from the paper's definitions and tables, without
consulting the first implementation (`hierarchy/certnest.js`, `synthnest.js`, `core/nest.js`), and shares no code
with it. Like every program here, it was written by the AI system.

    python3 second/nest2.py        # about a second; prints ALL CHECKS PASSED or FAILED (exit status 1)
    python3 second/check_exact_tables.py   # the transcribed tables against the exact extraction exact/exact_C.json
    python3 second/check_tex.py    # in the development repository only: the tables against the paper's source

`faults/faults.py` (the meeting of two or three supertiles, a corroboration of §7.3, and the second implementation of the 18
skeleton walks of Computation 7.2(b)) imports the tables, the affine arithmetic and the certifier of `nest2.py`, so
these also serve those computations.

What it does, and how it differs from the first implementation:

- **Input.** Tables "children", "sides", "psides", "letters", the level-1 vertex positions and lengths, transcribed
  from the paper and checked for internal consistency: gluing is an involution, glued sides carry the same letter
  with opposite signs, the parent's rim is exactly the rim sides, the recurrence follows from the tables, the
  level-1 vertices match the letters, the closed forms hold, and E_m(Δ) = 46, 182, 758, 3198, 13534.
- **Variables.** Lengths are integer affine functions of the eight *letter* lengths at the level of the base, with
  the Σ offset d = ζ (as in the first implementation, which builds its forms differently, through the 54 x 54 matrix
  M). Branches are taken at the actual bases b = 2 and b = 1. Every comparison is recorded, including the reduction
  of a parent position equal to the rim length; parities are fixed by Cor. "Parities are constant" and are not
  comparisons. Values cannot be compared except through the recorder.
- **Composition.** The skeleton of the Δ composition (marks, runs, partners, parities), the maps τ and σ, and the
  reduced walk, built from the definitions; at every level it checks that the parent has the signature, that there
  is no closed strand, that the parent's positions are those of a Δ of the next level, and property (iv) of a label
  state: the labels and stretches account for every arc of N_b exactly once.
- **Certificates.** By Lemma "Lower bounds" alone: every letter length is at least 5 at every level and
  δ - ζ = δ_m - d_m >= 4, so a·y + e >= 0 holds for every b >= 1 if, with c = max(0, -a_ζ), a - c(e_δ - e_ζ) has no
  negative coefficient and 5 sum(a') + 4c + e >= 0; an equality must hold identically. (`certify()`, a recurrence
  certificate h_{j+2} = 18 h_{j+1} - h_j built on the Fibonacci closed forms, is kept for `faults/faults.py`.)
- **Cross-checks.** Concrete runs for b = 1..40 take exactly the branches of the symbolic run of their parity; the
  numbers of blocks for b = 1..6, k = 1..4 equal Table "merge" (direct computations): 10, 37, 146, 613, 2586, 10949
  at k = 1, then 2, 1 or 2, 1.
- **Negative controls.** Seven deliberate errors (even and odd runs exchanged; a wrong crossover inside a child;
  the wrong sign of omega; one label per stretch part; rim parts dropped; Tables "psides" and "sides" corrupted) are
  each rejected, and the certifier rejects five false or unprovable obligations. Three other changes leave the outcome
  unchanged and so are not used as controls (see the comment in `negative()`).

Result: classes at relative levels 1-4 are 4, 2, 1, 1 for even b and 3, 2, 2, 1 for odd b, with no stretch from
level 2 on, as in the paper; 142 and 144 distinct obligations, all certified (the first implementation, which makes
its comparisons differently, records 583 and 564).
