# A second implementation of the merging computation

`nest2.py` repeats, separately, the computation behind Lemma "Uniformity in b" and Theorem "Merging" (Section 8 of
the paper): the label states (S1)-(S4) followed for 8 relative levels, symbolically for every base b >= 2 of each
parity, and the certificates for all b. It was written in Python from the paper's definitions and tables, without
consulting the first implementation (`hierarchy/certnest.js`, `synthnest.js`, `core/nest.js`,
`hierarchy/certify*.py`), and shares no code with it. Like every program here, it was written by the AI system.

    python3 second/nest2.py        # about 3 seconds; prints ALL CHECKS PASSED or FAILED (exit status 1)
    python3 second/check_tex.py    # in the development repository only: the tables against the paper's source

What it does, and how it differs from the first implementation:

- **Input.** Tables "children", "sides", "psides", "letters", the level-1 vertex positions and lengths, transcribed
  from the paper and checked for internal consistency: gluing is an involution, glued sides carry the same letter
  with opposite signs, the parent's rim is exactly the rim sides, the recurrence follows from the tables, the
  level-1 vertices match the letters, the closed forms hold, and E_m(Δ) = 46, 182, 758, 3198, 13534.
- **Variables.** Lengths are integer affine functions of the eight *letter* lengths one level below the base
  (the first implementation uses the 54 side lengths). Branches are taken at the actual bases b = 2 and b = 3 (the
  first uses the lengths of b = 2 for both parities). Every comparison is recorded; parities are fixed by
  Cor. "Parities are constant" and are not comparisons. Values cannot be compared except through the recorder.
- **Composition.** The skeleton of the Δ composition (marks, runs, partners, parities), the maps τ and σ, and the
  reduced walk, built from the definitions; at every level it checks that the parent has the signature, that there
  is no closed strand, that the parent's positions are those of a Δ of the next level, and property (iv) of a label
  state: the labels and stretches account for every arc of N_b exactly once.
- **Certificates.** A third method (the first implementation has two): with the Fibonacci closed forms an
  obligation is g = P F_n + Q F_{n+1} + R with n = 3(b-1)+1 stepping by 6, and h = P F_n + Q F_{n+1} satisfies
  h_{j+2} = 18 h_{j+1} - h_j; once 0 <= h_j <= h_{j+1}, h never decreases, so g >= 0 from there on, and earlier
  terms are checked directly.
- **Cross-checks.** Concrete runs for b = 2..40 take exactly the branches of the symbolic run of their parity; the
  numbers of blocks for b = 2..6, k = 1..4 equal Table "merge" (direct computations): 37, 146, 613, 2586, 10949 at
  k = 1, then 2, 1 or 2, 1.
- **Negative controls.** Seven deliberate errors (even and odd runs exchanged; a wrong crossover inside a child;
  the wrong sign of omega; one label per stretch part; rim parts dropped; Tables "psides" and "sides" corrupted) are
  each rejected, and the certifier rejects four false obligations. Three other changes leave the outcome
  unchanged and so are not used as controls (see the comment in `negative()`).

Result: classes at relative levels 1-4 are 4, 2, 1, 1 for even b and 3, 2, 2, 1 for odd b, with no stretch from
level 2 on, as in the paper; 150 distinct obligations for each parity, all certified (the first implementation, which makes its comparisons
differently, records 1,407 distinct).
