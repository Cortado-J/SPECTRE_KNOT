#!/usr/bin/env python3
"""Second implementation of the merging computation (Lemma "Uniformity in b" and Theorem "Merging").

Written from the paper's definitions and tables only (Sections 2-8), in Python, sharing no code with the first
implementation (hierarchy/certnest.js, synthnest.js, core/nest.js, hierarchy/certify*.py), which were not consulted.
Like every program here it was written by the AI system.

What it does:
  1. Transcribes Tables "children", "sides", "psides", "letters" and the level-1 data, and checks them for internal
     consistency (gluing is an involution, glued sides carry the same letter with opposite signs, the parent's rim is
     exactly the rim sides, the recurrence of Prop. "Lengths by letter" follows from the tables, the level-1 vertex
     positions match the letters, the Fibonacci closed forms hold).
  2. Builds the composition of a Delta-supertile from its eight children (Section 5: marks, runs, reduced ports, the
     maps tau and sigma) for given letter lengths, d and omega, and follows the reduced walk (Prop. "Reduced
     composition"); it checks that the parent has the signature.
  3. Runs the label-state steps (S1)-(S4) of Section 8 for 4 relative levels.  The same code runs
       - concretely, with integer lengths, for one base b, and
       - symbolically, every length an integer affine function of y = (letter lengths at level b), with the Σ offset
         d = ζ (both are 2 F_{3m+1}: Prop. "Fibonacci side lengths", Lemma "Position of A"), branching at a reference
         base (b = 2 for even b, b = 1 for odd b) and recording every comparison as an obligation f(y) >= 0 or f(y) = 0.
     Parities are not comparisons: they are fixed by Cor. "Parities are constant".
  4. Certifies every obligation for all bases b >= 1 by Lemma "Lower bounds" alone: every letter length is >= 5 at
     every level, and δ - ζ = δ_m - d_m >= 4. An inequality a.y + e >= 0 is certified if, with c = max(0, -a_ζ),
     a' = a - c(e_δ - e_ζ) is >= 0 coefficientwise and 5 sum(a') + 4c + e >= 0; an equality only if it holds
     identically. (The recurrence certificate certify() below, h_{j+2} = 18 h_{j+1} - h_j with the Fibonacci closed
     forms, is kept for faults/faults.py.)
  5. Compares the concrete runs for b = 1..40 with the symbolic run of the same parity (same branches, same numbers)
     and with Table "merge" of the paper (b = 1..6).

Usage: python3 second/nest2.py            (about a second)
"""
import sys

# ------------------------------------------------------------------------------------------------ the tables
KINDS = ['Γ', 'Δ', 'Θ', 'Λ', 'Ξ', 'Π', 'Σ', 'Φ', 'Ψ']
LET = ['α', 'β', 'γ', 'δ', 'ε', 'ζ', 'η', 'θ']           # letter order of the vectors below
NL = len(LET)

# Table "children"
CHILDREN = {
    'Γ': 'Π Δ Θ Σ Ξ Φ Γ', 'Δ': 'Ξ Δ Ξ Φ Σ Π Φ Γ', 'Θ': 'Ψ Δ Π Φ Σ Π Φ Γ', 'Λ': 'Ψ Δ Ξ Φ Σ Π Φ Γ',
    'Ξ': 'Ψ Δ Π Φ Σ Ψ Φ Γ', 'Π': 'Ψ Δ Ξ Φ Σ Ψ Φ Γ', 'Σ': 'Ξ Δ Ξ Φ Σ Π Λ Γ', 'Φ': 'Ψ Δ Ψ Φ Σ Π Φ Γ',
    'Ψ': 'Ψ Δ Ψ Φ Σ Ψ Φ Γ'}
CHILDREN = {k: v.split() for k, v in CHILDREN.items()}

# Table "sides": row c lists, for sides 0..5 of child c, "c'.j'" or "r" (on the parent's rim)
SIDES8 = ['7.1 r r r r 1.1', '7.2 0.5 r 2.0 3.0 4.0', '1.3 r r r r 3.1', '1.4 2.5 r r r 4.1',
          '1.5 3.5 r 5.0 6.0 7.3', '4.3 r r r r 6.1', '4.4 5.5 r r r 7.4', 'r 0.0 1.0 4.5 6.5 r']
SIDESG = ['6.1 r r r r 1.1', '6.2 0.5 r r 2.0 3.0', '1.4 r r r r 3.1', '1.5 2.5 r 4.0 5.0 6.3',
          '3.3 r r r r 5.1', '3.4 4.5 r r r 6.4', 'r 0.0 1.0 3.5 5.5 r']
def parse_sides(rows):
    out = []
    for row in rows:
        out.append([None if t == 'r' else tuple(int(x) for x in t.split('.')) for t in row.split()])
    return out
ADJ = {T: parse_sides(SIDESG if T == 'Γ' else SIDES8) for T in KINDS}

# Table "psides": the parent's rim in its own order, as pieces c.j, and the first position of each side
PIECES8 = '7.5 6.4 6.3 6.2 5.4 5.3 5.2 5.1 4.2 3.4 3.3 3.2 2.4 2.3 2.2 2.1 1.2 0.4 0.3 0.2 0.1 7.0'
PIECESG = '6.5 5.4 5.3 5.2 4.4 4.3 4.2 4.1 3.2 2.4 2.3 2.2 2.1 1.3 1.2 0.4 0.3 0.2 0.1 6.0'
FIRST = {'Δ': (0, 5, 7, 11, 14, 19), 'Θ': (0, 5, 7, 13, 15, 20), 'Λ': (0, 5, 7, 11, 14, 20), 'Ξ': (0, 3, 7, 13, 15, 20),
         'Π': (0, 3, 7, 11, 14, 20), 'Σ': (2, 5, 7, 11, 14, 19), 'Φ': (0, 5, 7, 11, 15, 20), 'Ψ': (0, 3, 7, 11, 15, 20),
         'Γ': (0, 3, 6, 11, 16, 18)}
PIECES = {T: [tuple(int(x) for x in t.split('.')) for t in (PIECESG if T == 'Γ' else PIECES8).split()] for T in KINDS}

# Table "letters" (the sign is kept as the second character; η has none)
LETTERS = {
    'Γ': 'α- α+ γ- δ- β+ β-', 'Δ': 'γ+ β+ ε- α+ γ- ζ-', 'Θ': 'γ+ β+ θ+ β+ η β-', 'Λ': 'γ+ β+ ε- α+ θ- β-',
    'Ξ': 'α- ε+ θ+ β+ η β-', 'Π': 'α- ε+ ε- α+ θ- β-', 'Σ': 'ζ+ β+ ε- α+ γ- δ+', 'Φ': 'γ+ β+ ε- ε+ η β-',
    'Ψ': 'α- ε+ ε- ε+ η β-'}
LETTERS = {k: v.split() for k, v in LETTERS.items()}
def letter(K, j): return LET.index(LETTERS[K][j][0])

# Level-1 data (proof of Prop. "pattern"): vertex positions counted from A in own order; E_1
LEVEL1 = {'Γ': (0, 7, 14, 24, 34, 39), 'Δ': (0, 10, 15, 23, 30, 40), 'Θ': (0, 10, 15, 26, 31, 41),
          'Λ': (0, 10, 15, 23, 30, 41), 'Ξ': (0, 7, 15, 26, 31, 41), 'Π': (0, 7, 15, 23, 30, 41),
          'Σ': (4, 10, 15, 23, 30, 40), 'Φ': (0, 10, 15, 23, 31, 41), 'Ψ': (0, 7, 15, 23, 31, 41)}
E1 = {K: 44 if K == 'Γ' else 46 for K in KINDS}
LAM1 = (7, 5, 10, 10, 8, 6, 10, 11)          # Prop. "Lengths by letter", m = 1
D1 = 6                                       # Lemma "Position of A", m = 1
# the recurrence (eq:rec), transcribed: row x lists the letters (with multiplicity) whose lengths add up to x_{m+1}
REC_TEXT = {'α': 'β ε η', 'β': 'α ε', 'γ': 'β ε ε η θ', 'δ': 'α β ε θ θ', 'ε': 'ε ε ε η', 'ζ': 'α ε θ', 'η': 'ε ε ε ε η',
            'θ': 'ε ε ε ε η θ'}
# Table "merge" (direct computations), b = 2..6, k = 1..4 (None: not computed)
TABLE_MERGE = {1: (10, 2, 2, 1), 2: (37, 2, 1, 1), 3: (146, 2, 2, 1), 4: (613, 2, 1, 1), 5: (2586, 2, 2, 1), 6: (10949, 2, 1, None)}

def fib(n):
    a, b = 0, 1
    for _ in range(n): a, b = b, a + b
    return a

problems = []
MUT = set()          # deliberate errors, for the negative controls only (see negative())
QUIET = [False]
def say(*a):
    if not QUIET[0]: print(*a)
def check(cond, what):
    if not cond: problems.append(what); say('  PROBLEM:', what)

def check_tables():
    say('== 1. the tables')
    for T in KINDS:
        n = len(CHILDREN[T]); adj = ADJ[T]
        check(len(adj) == n, f'{T}: {n} children but {len(adj)} rows in Table sides')
        # gluing is an involution, between different children, with the same letter and opposite signs
        for c in range(n):
            for j in range(6):
                if adj[c][j] is None: continue
                c2, j2 = adj[c][j]
                check(c2 != c and adj[c2][j2] == (c, j), f'{T}: {c}.{j} -> {c2}.{j2} is not returned')
                L1, L2 = LETTERS[CHILDREN[T][c]][j], LETTERS[CHILDREN[T][c2]][j2]
                check(L1[0] == L2[0], f'{T}: {c}.{j} and {c2}.{j2} carry different letters')
                check(L1 == 'η' and L2 == 'η' or {L1[1:], L2[1:]} == {'+', '-'}, f'{T}: {c}.{j}, {c2}.{j2} signs {L1}, {L2}')
        # the parent's rim is exactly the rim sides, each once
        rim = sorted((c, j) for c in range(n) for j in range(6) if adj[c][j] is None)
        check(sorted(PIECES[T]) == rim, f'{T}: pieces of Table psides are not the rim sides')
        # consecutive pieces of one child are consecutive sides (the parent traverses each child backwards)
        P = PIECES[T]
        for i in range(len(P)):
            (c, j), (c2, j2) = P[i], P[(i + 1) % len(P)]
            if c == c2: check(j2 == (j - 1) % 6, f'{T}: pieces {c}.{j}, {c2}.{j2} not consecutive sides')
        check(len(FIRST[T]) == 6 and list(FIRST[T]) == sorted(FIRST[T]), f'{T}: first positions')
    # the recurrence follows from the tables: every side of every parent with letter x is made of the same multiset
    rec = {}
    for T in KINDS:
        P, F = PIECES[T], FIRST[T]
        for J in range(6):
            a, b = F[J], F[(J + 1) % 6]
            idx = list(range(a, b)) if a < b else list(range(a, len(P))) + list(range(0, b))
            ms = sorted(LET[letter(CHILDREN[T][P[i][0]], P[i][1])] for i in idx)
            x = LETTERS[T][J][0]
            if x in rec: check(rec[x] == ms, f'letter {x}: side {J} of {T} gives {ms}, elsewhere {rec[x]}')
            else: rec[x] = ms
    for x in LET: check(sorted(REC_TEXT[x].split()) == rec.get(x), f'recurrence for {x}: tables give {rec.get(x)}')
    # level-1 data: vertex positions from A agree with the letters, E_1, and d_1
    for K in KINDS:
        V = LEVEL1[K]; E = E1[K]
        lens = [(V[(j + 1) % 6] - V[j]) % E for j in range(6)]
        check(lens == [LAM1[letter(K, j)] for j in range(6)], f'level 1 {K}: side lengths {lens}')
        check(sum(lens) == E, f'level 1 {K}: E_1')
    check((E1['Σ'] - LEVEL1['Σ'][5]) % E1['Σ'] == D1, 'd_1 from the level-1 Σ')
    say('  tables consistent' if not problems else '  TABLE PROBLEMS')
    return {x: [LET.index(t) for t in rec[x]] for x in LET}

# ------------------------------------------------------------------------------------------------ numbers
class Aff:
    """An integer affine function of y in Z^8 (y = letter lengths at level b). Comparisons go through Ctx only."""
    __slots__ = ('a', 'e')
    def __init__(self, a, e=0): self.a = tuple(a); self.e = e
    def __add__(self, o):
        if isinstance(o, Aff): return Aff([x + y for x, y in zip(self.a, o.a)], self.e + o.e)
        return Aff(self.a, self.e + o)
    __radd__ = __add__
    def __neg__(self): return Aff([-x for x in self.a], -self.e)
    def __sub__(self, o): return self + (-o)
    def __rsub__(self, o): return (-self) + o
    def __mul__(self, k):
        assert isinstance(k, int)
        return Aff([x * k for x in self.a], self.e * k)
    __rmul__ = __mul__
    def _no(self, *_): raise TypeError('compare Aff values through Ctx')
    __lt__ = __le__ = __gt__ = __ge__ = __eq__ = __ne__ = __bool__ = _no
    __hash__ = None
    def key(self): return self.a + (self.e,)
    def __repr__(self): return ' + '.join(f'{c}{LET[i]}' for i, c in enumerate(self.a) if c) + f' + {self.e}'

class Ctx:
    """Concrete (mode 'int') or symbolic (mode 'sym') arithmetic, with every comparison logged."""
    def __init__(self, mode, yref, ypar):
        self.mode, self.yref, self.ypar = mode, yref, ypar
        self.obl = []        # (f, kind): kind '>=' means f(y) >= 0, '=' means f(y) = 0
        self.trace = []      # the sign of every comparison, in order
    def val(self, x): return x if isinstance(x, int) else sum(c * v for c, v in zip(x.a, self.yref)) + x.e
    def sign(self, x):
        v = self.val(x); s = (v > 0) - (v < 0); self.trace.append(s)
        if isinstance(x, Aff) and any(x.a):
            if s > 0: self.obl.append((x - 1, '>='))
            elif s < 0: self.obl.append((-x - 1, '>='))
            else: self.obl.append((x, '='))
        return s
    def lt(self, x, y): return self.sign(x - y) < 0
    def le(self, x, y): return self.sign(x - y) <= 0
    def eq(self, x, y): return self.sign(x - y) == 0
    def par(self, x):
        """Parity, from the fixed parities of the letters (Cor. "Parities are constant"); not a comparison."""
        if isinstance(x, int): return x & 1
        return (sum(c * p for c, p in zip(x.a, self.ypar)) + x.e) & 1
    @staticmethod
    def same(x, y):
        """Structural identity (not a comparison): the same integer, or the same affine function."""
        if isinstance(x, Aff) or isinstance(y, Aff):
            ka = x.key() if isinstance(x, Aff) else (0,) * NL + (x,)
            kb = y.key() if isinstance(y, Aff) else (0,) * NL + (y,)
            return ka == kb
        return x == y

ZETA, DELTA = LET.index('ζ'), LET.index('δ')

def certify_bounds(obl):
    """Every obligation for every b >= 1, by Lemma "Lower bounds": letters >= 5, δ - ζ >= 4."""
    bad, via = 0, 0
    for f, kind in obl:
        if kind == '=':
            ok = not any(f.a) and f.e == 0
        else:
            c = max(0, -f.a[ZETA]); a = list(f.a); a[DELTA] -= c; a[ZETA] += c
            ok = all(x >= 0 for x in a) and 5 * sum(a) + 4 * c + f.e >= 0
            via += ok and c > 0
        if not ok: bad += 1; say('  NOT CERTIFIED:', f, kind)
    return bad, via

def apply_rec(R, lam): return [sum((lam[i] for i in R[LET[x]]), 0 * lam[0]) for x in range(NL)]

# ------------------------------------------------------------------------------------------------ the composition
class UF:
    def __init__(self): self.p = {}
    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x: self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b): self.p[self.find(a)] = self.find(b)

def compose(ctx, T, lam, d, om):
    """The composition of a T-supertile from its children of the level with letter lengths lam, Σ distance d and
    sign omega; children in their own orientation. Returns the skeleton data needed by the label steps."""
    kinds = CHILDREN[T]; n = len(kinds); adj = ADJ[T]
    L = [[lam[letter(K, j)] for j in range(6)] for K in kinds]
    V = []
    for c in range(n):
        v = [0 * lam[0]]
        for j in range(6): v.append(v[-1] + L[c][j])
        V.append(v)                                     # V[c][6] = E_c
    nb = lambda c, j: adj[c][j % 6][0] if adj[c][j % 6] else 'rim'
    # points: vertices ('v', c, j) and the crossover corners that are not vertices ('p', id); classes by gluing
    uf = UF()
    for c in range(n):
        for j in range(6):
            if adj[c][j]:
                c2, j2 = adj[c][j]
                uf.union(('v', c, j), ('v', c2, (j2 + 1) % 6)); uf.union(('v', c, (j + 1) % 6), ('v', c2, j2))
    # crossover corners: A_c, B_c = A_c + om in c's order. Interior points: (c, side, offset from vertex side)
    interior = {}                                       # (c, j) -> list of [point id, offset]
    AB = {}
    def add_interior(c, j, off, pid):
        check(ctx.lt(0, off) and ctx.lt(off, L[c][j]), f'point {pid} not inside side {c}.{j}')
        interior.setdefault((c, j), []).append([pid, off])
        if adj[c][j]:
            c2, j2 = adj[c][j]
            interior.setdefault((c2, j2), []).append([pid, L[c][j] - off])
    for c in range(n):
        if kinds[c] != 'Σ':
            A = ('v', c, 0)
            if om > 0: add_interior(c, 0, 1, ('p', c, 'B')); B = ('p', c, 'B')
            else: add_interior(c, 5, L[c][5] - 1, ('p', c, 'B')); B = ('p', c, 'B')
        else:
            add_interior(c, 5, d, ('p', c, 'A')); A = ('p', c, 'A')
            add_interior(c, 5, d + om, ('p', c, 'B')); B = ('p', c, 'B')
        AB[c] = (A, B)
    # coinciding interior points on a side are one mark
    for key, pts in interior.items():
        for i in range(len(pts)):
            for k in range(i + 1, len(pts)):
                if ctx.eq(pts[i][1], pts[k][1]): uf.union(pts[i][0], pts[k][0])
    g = uf.find
    # marks: junction vertices (of any child), crossover corners
    markset = set()
    for c in range(n):
        for j in range(6):
            if nb(c, j - 1) != nb(c, j): markset.add(g(('v', c, j)))
        markset.add(g(AB[c][0])); markset.add(g(AB[c][1]))
    # each child's marks in its own order: (gid, position)
    marks = []
    for c in range(n):
        seq = []
        for j in range(6):
            if g(('v', c, j)) in markset: seq.append((g(('v', c, j)), V[c][j], 'v', j))
            pts, seen = [], set()
            for pid, off in interior.get((c, j), []):
                if g(pid) in seen: continue
                seen.add(g(pid)); pts.append((g(pid), off))
            # sort by offset (comparisons); insertion sort keeps the number of comparisons small
            srt = []
            for p in pts:
                i = len(srt)
                while i > 0 and ctx.lt(p[1], srt[i - 1][1]): i -= 1
                srt.insert(i, p)
            seq += [(gid, V[c][j] + off, 'i', j) for gid, off in srt]
        check(len(seq) >= 4, f'child {c} has {len(seq)} marks')
        check(len({m[0] for m in seq}) == len(seq), f'child {c}: a mark occurs twice')
        marks.append(seq)
    # runs: run i of child c goes from marks[c][i] to marks[c][i+1]; its neighbour is that of its first edge
    runs = []
    for c in range(n):
        m = len(marks[c]); rr = []
        for i in range(m):
            u, p, _, j = marks[c][i]; u2, p2, kind2, j2 = marks[c][(i + 1) % m]
            ln = p2 - p if i + 1 < m else p2 + V[c][6] - p
            jlast = (j2 - 1) % 6 if kind2 == 'v' else j2          # side of the run's last edge
            # between its ends the run passes only vertices that are not junctions: one neighbour throughout
            jj = j
            while jj != jlast: check(nb(c, jj) == nb(c, jj + 1), f'run of child {c} crosses a junction'); jj = (jj + 1) % 6
            endpos = V[c][6] if (kind2 == 'v' and j2 == 0) else p2     # the end, measured along the run
            rr.append(dict(u=u, u2=u2, start=p, endpos=endpos, len=ln, side=j, lastside=jlast, nb=nb(c, j)))
        runs.append(rr)
    # partner runs and parities
    par_of = {}
    for c in range(n):
        for r in runs[c]:
            if r['nb'] == 'rim': continue
            c2 = r['nb']
            match = [r2 for r2 in runs[c2] if r2['u'] == r['u2'] and r2['u2'] == r['u']]
            check(len(match) == 1 and Ctx.same(match[0]['len'], r['len']), f'run of {c} from {r["u"]}: partner in {c2}')
            r['partner'] = c2; r['par'] = ctx.par(r['len'])
    # reduced ports (c, gid, 'R'|'L'); tau inside a child; sigma across interior runs
    tau, sig = {}, {}
    def link(D, a, b):
        check(D.get(a, b) == b and D.get(b, a) == a, f'inconsistent link {a} {b}')
        D[a] = b; D[b] = a
    for c in range(n):
        A, B = g(AB[c][0]), g(AB[c][1])
        for u, *_ in marks[c]:
            if u not in (A, B): link(tau, (c, u, 'L'), (c, u, 'R'))
        if 'tau' in MUT: link(tau, (c, A, 'R'), (c, B, 'L')); link(tau, (c, A, 'L'), (c, B, 'R'))
        else: link(tau, (c, A, 'R'), (c, B, 'R')); link(tau, (c, A, 'L'), (c, B, 'L'))
        for r in runs[c]:
            if r['nb'] == 'rim': continue
            u, u2, c2 = r['u'], r['u2'], r['partner']
            if (r['par'] == 0) != ('sigma' in MUT): link(sig, (c, u, 'R'), (c, u2, 'L')); link(sig, (c2, u2, 'R'), (c2, u, 'L'))
            else: link(sig, (c, u, 'R'), (c2, u2, 'R')); link(sig, (c, u2, 'L'), (c2, u, 'L'))
    parent_ports = set()
    for c in range(n):
        m = len(marks[c])
        for i in range(m):
            if runs[c][i]['nb'] == 'rim':
                parent_ports.add((c, runs[c][i]['u'], 'R')); parent_ports.add((c, runs[c][i]['u2'], 'L'))
    # the reduced walk: arcs of the parent, from parent port to parent port
    comp = {}
    arcs = []
    for p in sorted(parent_ports, key=repr):
        if p in comp: continue
        path = [p]; q = tau[p]; path.append(q)
        while q not in parent_ports:
            q = sig[q]; path.append(q); q = tau[q]; path.append(q)
        for x in path: comp[x] = len(arcs)
        arcs.append((p, q))
    allports = set(tau)
    check(all(x in comp for x in allports), 'a closed strand in the composition')
    # parent positions (parent's own order, from vertex 0 of the Γ child) of points on rim sides
    starts = {}; acc = 0 * lam[0]
    for (c, j) in PIECES[T]: starts[(c, j)] = acc; acc = acc + L[c][j]
    Eparent = acc
    def ppos_child(c, p, j):
        """Parent position of the point at position p of child c on its rim side j."""
        x = starts[(c, j)] + (V[c][j + 1] - p)
        return 0 * lam[0] if ctx.eq(x, Eparent) else x     # a recorded comparison
    # every parent mark starts exactly one rim run and ends exactly one; both give the same parent position
    ppos, pend = {}, {}
    for c in range(n):
        for r in runs[c]:
            if r['nb'] != 'rim': continue
            check(r['u'] not in ppos and r['u2'] not in pend, 'a parent mark starts or ends two rim runs')
            ppos[r['u']] = ppos_child(c, r['start'], r['side'])
            pend[r['u2']] = ppos_child(c, r['endpos'], r['lastside'])
    check(set(ppos) == set(pend), 'parent marks')
    for u in ppos: check(Ctx.same(ppos[u], pend[u]), f'parent position of mark {u}')
    Aplus, Bplus = g(AB[n - 1][0]), g(AB[n - 1][1])
    # the signature of the parent: hooks at every parent mark but A+, B+, and the crossover there
    pmarks = {x[1] for x in parent_ports}
    for (p, q) in arcs:
        if p[1] == q[1]: check(p[2] != q[2] and p[1] not in (Aplus, Bplus), f'arc {p} {q}')
        else: check({p[1], q[1]} == {Aplus, Bplus} and p[2] == q[2], f'arc {p} {q} is neither a hook nor the crossover')
    check(len(arcs) == len(pmarks) and Aplus in pmarks and Bplus in pmarks, 'number of arcs')
    # the parent's vertices: side J starts at the first position of side J (Table psides)
    pvert = [starts[PIECES[T][FIRST[T][J]]] for J in range(6)]
    return dict(marks=marks, runs=runs, tau=tau, sig=sig, comp=comp, arcs=arcs, ppos=ppos, V=V, L=L, E=Eparent,
                AB=AB, g=g, starts=starts, Aplus=Aplus, Bplus=Bplus, parent_ports=parent_ports, pvert=pvert)

# ------------------------------------------------------------------------------------------------ label states
class State:
    """A label state (Def. "Label state"). w2[label] is twice the number of arcs of N_b the label stands for, so that
    property (iv), every arc of N_b in exactly one label or stretch vertex, can be checked exactly."""
    def __init__(self): self.H = []; self.S = []; self.X = [None, None]; self.uf = UF(); self.n = 0; self.w2 = {}
    def fresh(self, w2=2): self.n += 1; self.uf.find(self.n); self.w2[self.n] = w2; return self.n

def locate(ctx, seq, u):
    """Index i of the last mark of child 1 at a position <= u (positions in [0, E)), and whether u is that mark."""
    i = 0
    while i + 1 < len(seq) and ctx.le(seq[i + 1][1], u): i += 1
    return i, ctx.eq(seq[i][1], u)

def step(ctx, st, K):
    """(S1)-(S4): from the state of N = child 1 to the state of the parent N+ (a Δ)."""
    c1 = 1; seq = K['marks'][c1]; runs = K['runs'][c1]
    side2 = 2
    check([j for j in range(6) if ADJ['Δ'][c1][j] is None] == [side2], 'child 1 meets the rim only on side 2')
    def P(u): return K['starts'][(c1, side2)] + (K['V'][c1][side2 + 1] - u)     # child 1 meets the rim only on side 2
    placed = {}
    def put(port, lab): placed.setdefault(port, []).append(lab)
    def hook_port(i, off):
        """Cor. "Where a hook goes": the reduced port on the arc of the hook at offset off inside run i of child 1."""
        r = runs[i]
        if ctx.par(off) == 0: return (c1, r['u'], 'R')
        if (r['par'] == 1) != ('placement' in MUT): return (c1, r['u2'], 'L')
        return (r['partner'], r['u2'], 'R')
    H2, S2 = [], []
    # (S1)
    for u, lab in st.H:
        i, at = locate(ctx, seq, u)
        if at: put((c1, seq[i][0], 'R'), lab)
        elif runs[i]['nb'] == 'rim': H2.append((P(u), lab))
        else: put(hook_port(i, u - seq[i][1]), lab)
    # (S2)
    for s, t in st.S:
        inside = []
        for i in range(len(seq)):
            if ctx.le(s, seq[i][1]) and ctx.le(seq[i][1], t): inside.append(i)
        parts, a = [], s
        for i in inside:
            lab = st.fresh(); put((c1, seq[i][0], 'R'), lab)
            parts.append((a, seq[i][1] - 1)); a = seq[i][1] + 1
        parts.append((a, t))
        for a, b in parts:
            if ctx.lt(b, a): continue
            i, at = locate(ctx, seq, a)
            check(not at, 'a stretch part starts at a mark')
            r = runs[i]
            if r['nb'] == 'rim':
                if 'dropS' not in MUT: S2.append((P(b), P(a)))
                continue
            off = a - seq[i][1]
            single = ctx.eq(a, b)
            pars = [ctx.par(off)] if single or 'oneparity' in MUT else [0, 1]
            n = b - a + 1                                   # vertices in the part; twice the number at each parity:
            for q in pars:
                if single: w2 = 2
                elif ctx.par(n) == 0: w2 = n                # n even: n/2 each
                else: w2 = n + 1 if ctx.par(off) == q else n - 1
                lab = st.fresh(w2); put(hook_port(i, off if ctx.par(off) == q else off + 1), lab)
    # (S3)
    A1 = K['g'](K['AB'][c1][0])
    xr, xl = ('L', 'R') if 'S3' in MUT else ('R', 'L')
    if st.X[0] is not None: put((c1, A1, xr), st.X[0])
    if st.X[1] is not None: put((c1, A1, xl), st.X[1])
    # (S4): labels on the same arc of N+ become equivalent
    on_arc = {}
    for port, labs in placed.items():
        a = K['comp'][port]
        on_arc.setdefault(a, []).extend(labs)
    for a, labs in on_arc.items():
        for x in labs[1:]: st.uf.union(x, labs[0])
    X2 = [None, None]
    n = len(CHILDREN['Δ']); Ap = K['Aplus']
    # the parent's own orientation is opposite to the children's: R(A+) in own order is L(A+) of the Γ child
    arcR = K['comp'][(n - 1, Ap, 'L')]; arcL = K['comp'][(n - 1, Ap, 'R')]
    for a, labs in on_arc.items():
        p, q = K['arcs'][a]
        if a == arcR: X2[0] = labs[0]
        elif a == arcL: X2[1] = labs[0]
        else:
            check(p[1] == q[1], 'a labelled arc is neither a hook nor a crossover arc')
            H2.append((K['ppos'][p[1]], labs[0]))
    st.H, st.S, st.X = H2, S2, X2
    return st

def classes(st):
    labs = [l for _, l in st.H] + [x for x in st.X if x is not None]
    roots = {st.uf.find(l) for l in labs}
    return len(roots), len(labs)

# ------------------------------------------------------------------------------------------------ one run
def run(ctx, R, y, b, levels=4):
    """The label states for base b, relative levels 1..levels; y = letter lengths at level b."""
    lam = list(y)                                       # level b
    om = 1 if b % 2 == 0 else -1                        # omega_b
    if 'omega' in MUT: om = -om
    E = sum((lam[letter('Δ', j)] for j in range(6)), 0 * lam[0])
    st = State(); st.X = [st.fresh(), st.fresh()]
    st.S = [(2, E - 1)] if om > 0 else [(1, E - 2)]
    E2 = 2 * E
    out = []
    for k in range(levels):
        d = lam[ZETA] + (1 if 'd' in MUT else 0)       # d_m = ζ_m
        K = compose(ctx, 'Δ', lam, d, om)
        st = step(ctx, st, K)
        ncls, nlab = classes(st)
        svert = sum((t - s + 1 for s, t in st.S), 0)
        out.append(dict(k=k + 1, classes=ncls, stretch=len(st.S), svert=svert, H=len(st.H)))
        check(ncls == nlab, 'two labelled arcs in one class')
        held = {st.uf.find(l) for _, l in st.H} | {st.uf.find(x) for x in st.X if x is not None}
        check(all(st.uf.find(l) in held for l in st.w2), f'relative level {k + 1}: a label was lost')
        total = sum((st.w2[l] for l in st.w2), 0 * lam[0]) + 2 * sum((t - s + 1 for s, t in st.S), 0 * lam[0])
        check(Ctx.same(total, E2), f'relative level {k + 1}: the labels and stretches do not account for every arc of N_b')
        lam, om = apply_rec(R, lam), -om
        # the parent's positions are the own positions of N+ as a Δ with the next lengths (vertex J at the sum of
        # its sides 0..J-1), so the state can be read as child 1 at the next step
        acc = 0 * lam[0]
        for J in range(6):
            check(Ctx.same(K['pvert'][J], acc), f'vertex {J} of the parent'); acc = acc + lam[letter('Δ', J)]
        check(Ctx.same(K['E'], acc), 'rim of the parent')
    return out

# ------------------------------------------------------------------------------------------------ certificates
def closed_form():
    """lambda_m = F_{3m+1} u + F_{3m+2} w + z (Prop. "Fibonacci side lengths"), in letter order."""
    u = (0, 1, 0, 0, 1, 2, 0, 1); w = (1, 0, 2, 2, 1, 0, 2, 2); z = (2, 2, 0, 0, 0, 0, 0, -2)
    return u, w, z

def certify(obl, m0):
    """Every obligation f(lambda_m) >= 0 (or = 0) for m = m0, m0+2, m0+4, ... (m = b-1)."""
    u, w, z = closed_form()
    bad = 0
    for f, kind in obl:
        P = sum(a * x for a, x in zip(f.a, u)); Q = sum(a * x for a, x in zip(f.a, w)); R = sum(a * x for a, x in zip(f.a, z)) + f.e
        h = lambda j: P * fib(3 * (m0 + 2 * j) + 1) + Q * fib(3 * (m0 + 2 * j) + 2)
        if kind == '=':
            ok = R == 0 and h(0) == 0 and h(1) == 0        # then h_j = 0 for all j by the recurrence
        else:
            ok = False
            for j0 in range(0, 200):
                if h(j0) + R < 0: break                    # fails at j0
                if 0 <= h(j0) <= h(j0 + 1): ok = True; break
        if not ok: bad += 1; say('  NOT CERTIFIED:', f, kind)
    return bad

def main():
    R = check_tables()
    # the recurrence and the closed forms agree, and give the rims and d of the paper
    lam = list(LAM1); u, w, z = closed_form()
    for m in range(1, 30):
        cf = [fib(3 * m + 1) * u[i] + fib(3 * m + 2) * w[i] + z[i] for i in range(NL)]
        check(cf == lam, f'closed form at level {m}')
        lam = apply_rec(R, lam)
    for n in range(1, 60): check(fib(n + 12) == 18 * fib(n + 6) - fib(n), 'F_{n+12} = 18 F_{n+6} - F_n')
    ypar = tuple(x & 1 for x in LAM1)                     # Cor. "Parities are constant"
    lams = [None, list(LAM1)]
    for m in range(2, 45): lams.append(apply_rec(R, lams[-1]))
    for m in range(1, 45): check(tuple(x & 1 for x in lams[m]) == ypar, f'parities at level {m}')
    E = [sum(lams[m][letter('Δ', j)] for j in range(6)) for m in range(1, 6)]
    check(E == [46, 182, 758, 3198, 13534], f'E_m(Δ) = {E}')
    say('  recurrence, closed forms, parities and E_m(Δ) agree with the paper')

    say('== 2-3. symbolic runs (one per parity of b), 4 relative levels')
    basis = [Aff([1 if i == k else 0 for i in range(NL)]) for k in range(NL)]
    sym = {}
    for parity, bref in ((0, 2), (1, 1)):
        ctx = Ctx('sym', lams[bref], ypar)
        res = run(ctx, R, basis, bref)
        sym[parity] = (res, ctx)
        uniq = {(f.key(), kind) for f, kind in ctx.obl}
        say(f'  {"even" if parity == 0 else "odd "} b (branches taken at b = {bref}): '
              f'classes at k = 1..4: {[r["classes"] for r in res]}; stretches: {[r["stretch"] for r in res]}; '
              f'{len(ctx.trace)} comparisons, {len(ctx.obl)} obligations ({len(uniq)} distinct, '
              f'{sum(1 for _, kd in uniq if kd == "=")} equalities)')

    say('== 4. certificates, for every b >= 1 of each parity (Lemma "Lower bounds")')
    total_bad = 0
    for parity in (0, 1):
        res, ctx = sym[parity]
        uniq = {}
        for f, kind in ctx.obl: uniq[(f.key(), kind)] = (f, kind)
        bad, via = certify_bounds(list(uniq.values()))
        total_bad += bad
        say(f'  {"even" if parity == 0 else "odd "} b: {len(uniq)} distinct obligations, {len(uniq) - bad} certified '
            f'({via} of them use δ - ζ >= 4, the rest only that every letter is >= 5)')
    check(total_bad == 0, 'uncertified obligations')

    say('== 5. concrete runs, b = 1..40, against the symbolic runs and Table "merge"')
    for b in range(1, 41):
        ctx = Ctx('int', lams[b], ypar)
        res = run(ctx, R, list(lams[b]), b)
        sres, sctx = sym[b % 2]
        check(ctx.trace == sctx.trace, f'b = {b}: branches differ from the symbolic run')
        check([r['classes'] for r in res] == [r['classes'] for r in sres], f'b = {b}: classes differ')
        counts = [r['classes'] + r['svert'] for r in res]
        if b in TABLE_MERGE:
            exp = TABLE_MERGE[b]
            got = tuple(counts[:4])
            check(all(e is None or e == g for e, g in zip(exp, got)), f'b = {b}: |P_k(b)| = {got}, Table "merge" {exp}')
            say(f'  b = {b}: |P_k(b)|, k = 1..4: {got}  (Table "merge": {exp})')
    say('  b = 1..40: same branches as the symbolic run of the same parity')

    even, odd = [r['classes'] for r in sym[0][0]], [r['classes'] for r in sym[1][0]]
    check(even[:4] == [4, 2, 1, 1] and odd[:4] == [3, 2, 2, 1], 'classes at k = 1..4')
    check(all(r['stretch'] == 0 for p in (0, 1) for r in sym[p][0][1:]), 'a stretch after relative level 1')
    say('== conclusion')
    if problems:
        say(f'{len(problems)} PROBLEMS'); return False
    say('for every b >= 1: P_3(b) has one block if b is even, P_4(b) has one block for every b; '
          'classes at k = 1..4: even b 4,2,1,1, odd b 3,2,2,1; no stretch from k = 2 on')
    say('SECOND IMPLEMENTATION AGREES')
    return True

def negative():
    """Negative controls: each deliberate error must make the run fail."""
    import copy
    global PIECES, ADJ
    saved = (copy.deepcopy(PIECES), copy.deepcopy(ADJ))
    def corrupt_pieces():   # exchange two pieces of the parent's rim (Table psides)
        for T in KINDS:
            if T != 'Γ': PIECES[T][3], PIECES[T][4] = PIECES[T][4], PIECES[T][3]
    def corrupt_sides():    # exchange the partners of two interior sides (Table sides), consistently
        for T in KINDS:
            if T == 'Γ': continue
            a = ADJ[T]; a[1][3], a[1][4] = a[1][4], a[1][3]; a[2][0], a[3][0] = (1, 4), (1, 3)
    # (Three other changes are not usable as controls, because they do not change the outcome: sending odd-offset
    # hooks to the other port of Cor. "Where a hook goes" leaves every partition unchanged, since both ports lie on
    # one arc of the parent wherever the rule is used; moving the Σ child's crossover corners one step along their
    # side (d + 1) flips the parities of the two runs beside them and leaves every arc and partition unchanged;
    # exchanging the two crossover labels in (S3) changes the partitions at relative levels 1-3 but not their numbers
    # of blocks.)
    cases = [('sigma: even and odd runs exchanged', {'sigma'}, None),
             ('tau: the crossover inside a child joined R(A) to L(B)', {'tau'}, None),
             ('omega: wrong sign of omega', {'omega'}, None),
             ('S2: one label per interior part, whatever its parities', {'oneparity'}, None),
             ('S2: rim parts of a stretch dropped', {'dropS'}, None),
             ('Table psides corrupted', set(), corrupt_pieces),
             ('Table sides corrupted', set(), corrupt_sides)]
    caught = 0
    for name, mut, fn in cases:
        problems.clear(); MUT.clear(); MUT.update(mut)
        PIECES, ADJ = copy.deepcopy(saved[0]), copy.deepcopy(saved[1])
        globals()['PIECES'], globals()['ADJ'] = PIECES, ADJ
        if fn: fn()
        QUIET[0] = True
        try: ok = main()
        except Exception as e: ok = False
        QUIET[0] = False
        caught += not ok
        print(f'  {"rejected" if not ok else "NOT REJECTED"}: {name}')
    problems.clear(); MUT.clear()
    globals()['PIECES'], globals()['ADJ'] = saved
    # the certifier must reject false or unprovable obligations
    e = lambda i: Aff([1 if k == i else 0 for k in range(NL)])
    false = [(1000 - e(0), '>=', 'α <= 1000 (false for large b)'), (e(0) - 30, '>=', 'α >= 30 (false at the first bases)'),
             (e(0) - e(1), '=', 'α = β'), (e(DELTA) - e(ZETA) - 5, '>=', 'δ - ζ >= 5 (false at b = 1)'),
             (e(ZETA) - e(DELTA) + 100, '>=', 'ζ - δ + 100 >= 0 (true at the first bases, false later)')]
    QUIET[0] = True
    for f, kind, name in false:
        rej = certify_bounds([(f, kind)])[0] == 1
        caught += rej; print(f'  {"rejected" if rej else "NOT REJECTED"} by the certifier: {name}')
    QUIET[0] = False
    return caught == len(cases) + len(false)

if __name__ == '__main__':
    ok = main()
    print('== negative controls (deliberate errors; each must be rejected)')
    neg = negative()
    print('ALL NEGATIVE CONTROLS REJECTED' if neg else 'A NEGATIVE CONTROL WAS NOT REJECTED')
    print('SECOND IMPLEMENTATION: ALL CHECKS PASSED' if ok and neg else 'FAILED')
    sys.exit(0 if ok and neg else 1)
