#!/usr/bin/env python3
"""No closed strand where two or three supertiles meet (the computation behind Theorem A for every tiling).

By the localisation lemma of the paper, a closed strand in any homochiral tiling would, at every level m whose
shortest side is longer than the strand, be a closed strand of the union of
  (P) two level-m supertiles sharing a side, or
  (V) three level-m supertiles around one of their vertices,
each having the signature. This program checks, for every such configuration allowed by the matching rule
(glued sides carry the same letter with opposite signs, or both eta) and for every level m >= 1, that the union has
no closed strand. It builds the union from its "children" (the two or three supertiles) exactly as the paper builds
a composition: marks, runs, the maps tau and sigma, and the alternation of Prop. "Reduced composition"; the closed
strands of the union are the cycles of the alternation that contain no port on the union's rim.

Lengths: letter lengths lambda_m and d_m = zeta_m (both equal 2F_{3m+1}: Prop. "Fibonacci side lengths" and Lemma
"Position of A"). The run is symbolic in y = lambda_m, branching at m = 1 (odd m) and m = 2 (even m), and every
comparison is recorded and certified for all m of that parity, with the certifier of second/nest2.py. Concrete runs
for m = 1..14 must take the same branches. Negative controls: configurations that break the matching rule, and a
wrong crossover, must produce closed strands.

Written by the AI system, like every program here.  Usage: python3 faults/faults.py   (about 10 seconds)
"""
import os, sys, itertools
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', 'second'))
import nest2 as N
from nest2 import Aff, Ctx, KINDS, LET, NL, LETTERS, letter, UF

problems = []
def check(cond, what):
    if not cond: problems.append(what); print('  PROBLEM:', what)

def matches(K1, j1, K2, j2):
    """The matching rule: glued sides carry the same letter, with opposite signs (or both eta)."""
    a, b = LETTERS[K1][j1], LETTERS[K2][j2]
    return a[0] == b[0] and (a == 'η' and b == 'η' or {a[1:], b[1:]} == {'+', '-'})

def union_cycles(ctx, kinds, adj, lam, om, flip_crossover=False):
    """Closed strands of the union of boxes (one per entry of kinds), all of one level with letter lengths lam,
    each with the signature at (A, A + om) in its own orientation; adj[c][j] = (c', j') if side j of c is side j' of
    c' (traversed oppositely), else None (on the union's rim). Returns the number of closed strands."""
    n = len(kinds); d = lam[LET.index('ζ')]                 # d_m = zeta_m
    L = [[lam[letter(K, j)] for j in range(6)] for K in kinds]
    V = []
    for c in range(n):
        v = [0 * lam[0]]
        for j in range(6): v.append(v[-1] + L[c][j])
        V.append(v)
    nb = lambda c, j: adj[c][j % 6][0] if adj[c][j % 6] else 'rim'
    uf = UF()
    for c in range(n):
        for j in range(6):
            uf.find(('v', c, j))
            if adj[c][j]:
                c2, j2 = adj[c][j]
                uf.union(('v', c, j), ('v', c2, (j2 + 1) % 6)); uf.union(('v', c, (j + 1) % 6), ('v', c2, j2))
    interior, AB = {}, {}
    def add_interior(c, j, off, pid):
        check(ctx.lt(0, off) and ctx.lt(off, L[c][j]), f'point {pid} not inside side {c}.{j}')
        interior.setdefault((c, j), []).append([pid, off])
        if adj[c][j]:
            c2, j2 = adj[c][j]; interior.setdefault((c2, j2), []).append([pid, L[c][j] - off])
    for c in range(n):
        if kinds[c] != 'Σ':
            A = ('v', c, 0)
            if om > 0: add_interior(c, 0, 1, ('p', c, 'B'))
            else: add_interior(c, 5, L[c][5] - 1, ('p', c, 'B'))
        else:
            add_interior(c, 5, d, ('p', c, 'A')); A = ('p', c, 'A')
            add_interior(c, 5, d + om, ('p', c, 'B'))
        AB[c] = (A, ('p', c, 'B'))
    for pts in interior.values():
        for i in range(len(pts)):
            for k in range(i + 1, len(pts)):
                if ctx.eq(pts[i][1], pts[k][1]): uf.union(pts[i][0], pts[k][0])
    g = uf.find
    markset = set()
    for c in range(n):
        for j in range(6):
            if nb(c, j - 1) != nb(c, j): markset.add(g(('v', c, j)))
        markset.add(g(AB[c][0])); markset.add(g(AB[c][1]))
    marks = []
    for c in range(n):
        seq = []
        for j in range(6):
            if g(('v', c, j)) in markset: seq.append((g(('v', c, j)), V[c][j], 'v', j))
            pts, seen = [], set()
            for pid, off in interior.get((c, j), []):
                if g(pid) not in seen: seen.add(g(pid)); pts.append((g(pid), off))
            srt = []
            for p in pts:
                i = len(srt)
                while i > 0 and ctx.lt(p[1], srt[i - 1][1]): i -= 1
                srt.insert(i, p)
            seq += [(gid, V[c][j] + off, 'i', j) for gid, off in srt]
        check(len(seq) >= 2 and len({x[0] for x in seq}) == len(seq), f'marks of box {c}')
        marks.append(seq)
    runs = []
    for c in range(n):
        m = len(marks[c]); rr = []
        for i in range(m):
            u, p, _, j = marks[c][i]; u2, p2, kind2, j2 = marks[c][(i + 1) % m]
            ln = p2 - p if i + 1 < m else p2 + V[c][6] - p
            jlast = (j2 - 1) % 6 if kind2 == 'v' else j2
            jj = j
            while jj != jlast: check(nb(c, jj) == nb(c, jj + 1), f'run of box {c} crosses a junction'); jj = (jj + 1) % 6
            rr.append(dict(u=u, u2=u2, len=ln, nb=nb(c, j)))
        runs.append(rr)
    for c in range(n):
        for r in runs[c]:
            if r['nb'] == 'rim': continue
            match = [r2 for r2 in runs[r['nb']] if r2['u'] == r['u2'] and r2['u2'] == r['u']]
            check(len(match) == 1 and Ctx.same(match[0]['len'], r['len']), f'partner of a run of box {c}')
            r['par'] = ctx.par(r['len'])
    tau, sig = {}, {}
    def link(D, a, b):
        check(D.get(a, b) == b and D.get(b, a) == a, f'inconsistent link {a} {b}'); D[a] = b; D[b] = a
    for c in range(n):
        A, B = g(AB[c][0]), g(AB[c][1])
        for u, *_ in marks[c]:
            if u not in (A, B): link(tau, (c, u, 'L'), (c, u, 'R'))
        if flip_crossover: link(tau, (c, A, 'R'), (c, B, 'L')); link(tau, (c, A, 'L'), (c, B, 'R'))
        else: link(tau, (c, A, 'R'), (c, B, 'R')); link(tau, (c, A, 'L'), (c, B, 'L'))
        for r in runs[c]:
            if r['nb'] == 'rim': continue
            u, u2, c2 = r['u'], r['u2'], r['nb']
            if r['par'] == 0: link(sig, (c, u, 'R'), (c, u2, 'L')); link(sig, (c2, u2, 'R'), (c2, u, 'L'))
            else: link(sig, (c, u, 'R'), (c2, u2, 'R')); link(sig, (c, u2, 'L'), (c2, u, 'L'))
    rimports = set()
    for c in range(n):
        for r in runs[c]:
            if r['nb'] == 'rim': rimports.add((c, r['u'], 'R')); rimports.add((c, r['u2'], 'L'))
    seen = set()
    for p in sorted(rimports, key=repr):
        if p in seen: continue
        q = p; seen.add(q); q = tau[q]; seen.add(q)
        while q not in rimports:
            q = sig[q]; seen.add(q); q = tau[q]; seen.add(q)
    cycles, left = 0, set(tau) - seen
    while left:
        q0 = left.pop(); q = q0; cycles += 1
        while True:
            q = tau[q]; left.discard(q); q = sig[q]; left.discard(q)
            if q == q0: break
    return cycles

# ------------------------------------------------------------------------------------------------ configurations
def pair_configs(require_match=True):
    """(P): box 0 side j glued to box 1 side j2."""
    for K1, K2 in itertools.product(KINDS, KINDS):
        for j1 in range(6):
            for j2 in range(6):
                if require_match and not matches(K1, j1, K2, j2): continue
                adj = [[None] * 6 for _ in range(2)]; adj[0][j1] = (1, j2); adj[1][j2] = (0, j1)
                yield (K1, K2), adj, f'{K1}.{j1}|{K2}.{j2}'

def star_configs(require_match=True):
    yield from _star_configs(require_match)
def _star_configs(require_match=True):
    """(V): three boxes around a point u, box i with its vertex j_i at u; in the common orientation side j_i of box i
    (which starts at u) is glued to side j_{i+1} - 1 of box i+1 (which ends at u)."""
    for Ks in itertools.product(KINDS, repeat=3):
        for js in itertools.product(range(6), repeat=3):
            glue = [(i, js[i], (i + 1) % 3, (js[(i + 1) % 3] - 1) % 6) for i in range(3)]
            if require_match and not all(matches(Ks[a], ja, Ks[b], jb) for a, ja, b, jb in glue): continue
            adj = [[None] * 6 for _ in range(3)]
            for a, ja, b, jb in glue: adj[a][ja] = (b, jb); adj[b][jb] = (a, ja)
            yield Ks, adj, f'{Ks[0]}{js[0]} {Ks[1]}{js[1]} {Ks[2]}{js[2]}'
def loose_star_configs():
    """Vertex stars glued by letter only, ignoring the signs of the matching rule (sides of equal length)."""
    for Ks in itertools.product(KINDS, repeat=3):
        for js in itertools.product(range(6), repeat=3):
            glue = [(i, js[i], (i + 1) % 3, (js[(i + 1) % 3] - 1) % 6) for i in range(3)]
            if not all(LETTERS[Ks[a]][ja][0] == LETTERS[Ks[b]][jb][0] for a, ja, b, jb in glue): continue
            if all(matches(Ks[a], ja, Ks[b], jb) for a, ja, b, jb in glue): continue
            adj = [[None] * 6 for _ in range(3)]
            for a, ja, b, jb in glue: adj[a][ja] = (b, jb); adj[b][jb] = (a, ja)
            yield Ks, adj, f'{Ks[0]}{js[0]} {Ks[1]}{js[1]} {Ks[2]}{js[2]}'

# ------------------------------------------------------------------------------------------------ can it occur?
def parent_data():
    """For each parent kind T: the vertex classes of its children (points identified by Table sides) and the classes of
    the parent's six vertices (the start, in the parent's order, of the piece at the first position of each side)."""
    out = {}
    for T in KINDS:
        uf = UF(); adj = N.ADJ[T]; n = len(N.CHILDREN[T])
        for c in range(n):
            for j in range(6):
                uf.find(('v', c, j))
                if adj[c][j]:
                    c2, j2 = adj[c][j]
                    uf.union(('v', c, j), ('v', c2, (j2 + 1) % 6)); uf.union(('v', c, (j + 1) % 6), ('v', c2, j2))
        pv = set()
        for J in range(6):
            c0, j0 = N.PIECES[T][N.FIRST[T][J]]
            pv.add(uf.find(('v', c0, (j0 + 1) % 6)))           # piece c0.j0 runs from vertex j0+1 to vertex j0 of c0
        out[T] = (uf, pv)
    return out
PD = None
def can_be_parent_vertex(K, j):
    """Can vertex j of a supertile of kind K (level >= 1) be a vertex of its parent, for some placement as a child?"""
    for T in KINDS:
        uf, pv = PD[T]
        for c, Kc in enumerate(N.CHILDREN[T]):
            if Kc == K and uf.find(('v', c, j)) in pv: return True
    return False
def can_be_siblings(Ka, ja, Kb, jb):
    """Can a K_a and a K_b be children of one parent, glued along side j_a of the first and j_b of the second?"""
    return any(N.CHILDREN[T][c] == Ka and N.CHILDREN[T][c2] == Kb and N.ADJ[T][c][ja] == (c2, jb)
               for T in KINDS for c in range(len(N.CHILDREN[T])) for c2 in range(len(N.CHILDREN[T])))
def star_impossible(name, kinds, adj):
    """A vertex star (V) cannot occur if no two of its supertiles can be siblings (so their three parents are
    distinct, and the common point, on the rims of three parents, must be a vertex of each) while for some supertile
    the vertex at the common point is never a vertex of its parent."""
    js = [int(x[1:]) if x[0] != 'Σ' else int(x[1:]) for x in name.split()]
    glued = [(a, ja, b, jb) for a in range(3) for ja in range(6) if adj[a][ja] for b, jb in [adj[a][ja]] if a < b]
    if any(can_be_siblings(kinds[a], ja, kinds[b], jb) or can_be_siblings(kinds[b], jb, kinds[a], ja) for a, ja, b, jb in glued):
        return False, 'two of its supertiles could be siblings'
    bad = [i for i in range(3) if not can_be_parent_vertex(kinds[i], js[i])]
    if not bad: return False, 'every vertex at the common point can be a parent vertex'
    return True, (f'no two can be siblings; vertex {js[bad[0]]} of a {kinds[bad[0]]} is never a vertex of its parent '
                  f'(Table psides), yet the common point lies on the rims of three distinct parents')

def run_all(ctx, lam, om, configs, **kw):
    out = []
    for kinds, adj, name in configs:
        out.append((name, union_cycles(ctx, list(kinds), adj, lam, om, **kw)))
    return out

def main():
    R = N.check_tables() if False else None
    N.QUIET[0] = True; R = N.check_tables(); N.QUIET[0] = False
    check(not N.problems, 'tables')
    lams = [None, list(N.LAM1)]
    for m in range(2, 20): lams.append(N.apply_rec(R, lams[-1]))
    for m in range(1, 20): check(lams[m][LET.index('ζ')] == 2 * N.fib(3 * m + 1), f'zeta_m = d_m = 2F(3m+1) at level {m}')
    ypar = tuple(x & 1 for x in N.LAM1)
    global PD
    PD = parent_data()
    P, S = list(pair_configs()), list(star_configs())
    byname = {nm: (k, a) for k, a, nm in P + S}
    print(f'== configurations allowed by the matching rule: {len(P)} side pairs, {len(S)} vertex stars')
    print('== symbolic runs, y = lambda_m (one per parity of m)')
    basis = [Aff([1 if i == k else 0 for i in range(NL)]) for k in range(NL)]
    sym = {}
    for mref in (1, 2):
        om = -1 if mref % 2 else 1
        ctx = Ctx('sym', lams[mref], ypar)
        res = run_all(ctx, basis, om, P + S)
        flagged = [nm for nm, cy in res if cy]
        for nm in flagged:
            kinds, adj = byname[nm]
            if nm in {x[2] for x in P}: check(False, f'a side pair with a closed strand: {nm}'); continue
            imp, why = star_impossible(nm, kinds, adj)
            check(imp, f'vertex star {nm} has a closed strand and is not shown impossible ({why})')
            print(f'  {"odd " if mref % 2 else "even"} m: vertex star {nm} has a closed strand, but cannot occur in any tiling: {why}')
        uniq = {}
        for f, kind in ctx.obl: uniq[(f.key(), kind)] = (f, kind)
        N.QUIET[0] = True; nbad = N.certify(list(uniq.values()), mref); N.QUIET[0] = False
        check(nbad == 0, f'{nbad} obligations not certified')
        sym[mref] = (res, ctx)
        print(f'  {"odd " if mref % 2 else "even"} m (branches at m = {mref}): {sum(1 for _, cy in res if cy)} of {len(res)} '
              f'configurations have a closed strand; {len(ctx.trace)} comparisons, {len(uniq)} distinct obligations, '
              f'{len(uniq) - nbad} certified for every m >= {mref} of this parity')
    print('== concrete runs, m = 1..14')
    for m in range(1, 15):
        om = -1 if m % 2 else 1
        ctx = Ctx('int', lams[m], ypar)
        res = run_all(ctx, lams[m], om, P + S)
        flagged_m = sorted(nm for nm, cy in res if cy)
        flagged_sym = sorted(nm for nm, cy in sym[1 if m % 2 else 2][0] if cy)
        check(flagged_m == flagged_sym, f'level {m}: closed strands in {flagged_m}, symbolic run {flagged_sym}')
        check(ctx.trace == sym[1 if m % 2 else 2][1].trace, f'level {m}: branches differ from the symbolic run')
    print('  m = 1..14: the same configurations have closed strands as in the symbolic run, with the same branches')
    print('== sanity check: the same code on the nine full compositions (no closed strand, by Theorem "Signature")')
    for m in range(1, 9):
        om = -1 if m % 2 else 1
        ctx = Ctx('int', lams[m], ypar)
        for T in KINDS:
            cy = union_cycles(ctx, list(N.CHILDREN[T]), N.ADJ[T], lams[m], om)
            check(cy == 0, f'composition of {T} from level {m}: {cy} closed strands')
    print('  compositions of all nine kinds from children of levels 1..8: no closed strand')
    print('== negative controls (each must produce closed strands)')
    neg_ok = True
    for name, configs, kw in (('vertex stars glued by letter but against the signs of the matching rule', list(loose_star_configs()), {}),):
        found = {}
        for m in (1, 2):
            om = -1 if m % 2 else 1
            ctx = Ctx('int', lams[m], ypar)
            res = run_all(ctx, lams[m], om, configs, **kw)
            found[m] = [nm for nm, cy in res if cy]
        n = len(found[1]) + len(found[2])
        neg_ok &= n > 0
        ex = (found[1] or found[2])[:3]
        print(f'  {"closed strands found" if n else "NONE FOUND"}: {name} ({len(found[1])} at m = 1, {len(found[2])} at m = 2; e.g. {ex})')
    check(neg_ok, 'a negative control found no closed strand')
    if problems:
        print(f'{len(problems)} PROBLEMS\nFAILED'); sys.exit(1)
    print('NO CLOSED STRAND WHERE TWO OR THREE SUPERTILES MEET, AT ANY LEVEL: ALL CHECKS PASSED')

if __name__ == '__main__':
    main()
