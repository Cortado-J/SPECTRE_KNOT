# The Spectre Knot: programs for the proof

This folder holds every program used in the paper *The Spectre Knot: one endless strand on an aperiodic monotile*
(`../spectre_knot.pdf`), with the logs of a full run. It is self-contained: it reads nothing outside this folder.

## Running

```
./run_all.sh          # stage A: the computations the proof depends on (about 12 minutes on 4 cores)
./run_all.sh --all    # stage A and stage B: corroboration up to level 9 (about 1 hour; node heap capped at 6.5 GB)
./run_all.sh --b      # stage B only (needs the data files written by stage A)
SMKGS_PDF=/path/to/spectre-paper.pdf ./run_all.sh   # also A17-A18: comparison with Figs. 4.1 and 5.1 of the spectre paper
```

Each step writes one log in `logs/` and prints its last line. A step that fails stops the run with a non-zero
exit status. Requirements:

- node 18 or later (tested with v22);
- python 3 with `numpy` and `scipy` (used only by `hierarchy/certify.py`), `sympy` (`hierarchy/letters.py`);
- `exact/exact.py` needs only the Python standard library.

## Two separate implementations (both written by the AI system)

- **JavaScript** (`core/` and most of `hierarchy/`): builds the supertiles with the key-point construction of the
  spectre paper (App. A) in floating point. Points are identified by rounding to 1/100 (`core/reduce.js`,
  `core/hier2.js`) or 1/1000 (`core/hier.js`). The rounding error is not bounded; the results are corroborated:
  `referee/overlap.js` (same construction, snapping to 1/1000) finds distinct vertices at least 0.89 apart and
  identified points within 4e-12 of each other up to level 7; up to level 9 every rim has exactly E_m edges and every
  rim vertex has degree 2 (`core/hier2.js` stops otherwise); and every geometric computation the proof uses is
  repeated in exact arithmetic by `exact/exact.py`.
- **Python** (`exact/exact.py`): written separately and sharing no code with the JavaScript. Every vertex is an
  element of Z[zeta], zeta = e^(i pi/6), stored as four integers, so all identifications are exact. It recomputes
  the base data (levels 1 to 4) and the nest merging for bases 1 to 3, and compares its results with the
  JavaScript output.

In the comments and printed output of the JavaScript programs, "exact" usually means the direct composition of
the actual tiles (floating point, with rounded keys), as opposed to the reduced walk. Exact arithmetic in the strict
sense is used only by `exact/exact.py`, the skeleton walks and symbolic run (integers) and the certificates.

The merging computation (the label states of Section 8 and their certificates) has a second, separate
implementation in Python, `second/nest2.py`, written from the paper's definitions and tables without consulting
the first; see `second/README.md`.

The symbolic certificate for the merging (`hierarchy/certnest.js`) is checked twice: once by linear programming
proposals verified in exact rationals (`certify.py`), and once by the Fibonacci closed form with integers only
(`certify_fib.py`).

## Which script checks which statement

Numbering as in the paper.

| statement | what is computed | script | log |
|---|---|---|---|
| Def. 3.1, Lemma 4.4 | the tile's 14 pieces = 12 hooks + crossover at v0 v1; the Mystic has the signature | `core/tile.js`, `exact/exact.py` | A01, A13 |
| §3.2 (drawing) | every shared tile edge glues e_i to e_j with i+j odd, opposite directions, levels 1-4 | `exact/exact.py` | A13 |
| Thm 2.1(b), Prop. 2.4 | the six vertices of every kind (points where three supertiles meet): observed at levels 1-4, and at levels 5-6 to check the propagated ones | `hierarchy/vertices.js`, `exact/exact.py` | A02, A03, A13 |
| Prop. 2.4, Rem. 2.5 | the composition pattern C of m -> m+1, m = 1..7, all identical (exact for m <= 3); vertices propagated for m >= 5 and checked against observation at 5-6 | `hierarchy/combin.js`, `exact/exact.py` | A04, A13 |
| Prop. 2.4 (base of (*)) | the level-1 supertiles as hat/turtle clusters (odd edges lengthened to sqrt 3), fitted to a 300-dpi render of the spectre paper's Fig. 4.1: six dots found per cluster, proper similarity with residual < 1% of an edge (other matchings and other kinds >= 40 times worse), rim on the printed outline, first Mystic tile on the lighter shading, labels (read by hand, `referee/fig41_labels.json`) = Table 4. Needs the spectre paper's PDF | `referee/fig41_compare.py` | A17 |
| Prop. 2.4 (base of (*)) | the same clusters drawn for comparison by eye | `referee/fig41_render.py` | `logs/A16_fig41_render.pdf` |
| Prop. 2.4, Rem. 2.5 | C agrees with a hand encoding of the spectre paper's Fig. 5.1, all nine kinds, including the parent side labels (dictionary (*) in the proof of Prop. 2.4) | `referee/fig51_compare.py` (encoding `referee/fig51_encoding.json`) | A06 |
| Rem. 2.5 | two deliberately corrupted encodings (`referee/neg_swap/`, `referee/neg_label/`) are rejected | `referee/fig51_compare.py` | A06b |
| Rem. 2.5 | the vertex dots and Gamma centres used by `fig51_compare.py` re-found on a 400-dpi render of Fig. 5.1 (within 2 px). Needs the spectre paper's PDF | `referee/fig51_raster.py` | A18 |
| Rem. 2.5 | tiles of every supertile, levels 1-7, have disjoint interiors and fill the rim | `referee/overlap.js` (levels 1-5; levels 6-7 take ~15 min) | B08, B13 |
| Prop. 6.1, 6.2, Cor. 6.3, Lemma 6.4 | side lengths by letter at levels 1-8, the recurrence, the Fibonacci closed forms, parities, the Sigma offset | `hierarchy/recur.js`, `hierarchy/letters.py` | A05, A07 |
| Comp. 7.2 | signature at levels 1-3 (and 4) for all nine kinds, exact | `exact/exact.py`, `hierarchy/checks.js` | A13, A08 |
| Comp. 7.5 | the 18 skeleton walks S_T(l_1, d_1, ±1); the parity lemma with other lengths | `hierarchy/induction.js` | A09 |
| Comp. 7.5 | the same 18 skeletons equal the skeletons of the actual supertiles at levels 2-9 (the encoding records slightly more than Def. 5.3, e.g. rim-run parities) | `hierarchy/induction.js 9` | B15 |
| Prop. 5.4 (check) | reduced walk = exact composition at all 1,424 parent ports, levels 1-8 | `hierarchy/checks.js` | B02 |
| Def. 8.6, Lemma 8.7 | label states and the step (S1)-(S4): implemented numerically in `core/nest.js` and symbolically in `hierarchy/certnest.js` (function `runSym`) | `core/nest.js`, `hierarchy/certnest.js` | A14, A10 |
| Lemma 8.8 | symbolic label computation: 1,068 obligations (even b) and 1,038 (odd b), 1,407 distinct; 1,001 + 979 certified directly | `hierarchy/certnest.js` | A10 |
| Lemma 8.8 | the 67 + 59 remaining obligations (118 distinct), by the Fibonacci closed form / by Krylov-space certificates | `hierarchy/certify_fib.py`, `hierarchy/certify.py` | A12, A11 |
| Def. 8.6, Lemmas 8.7, 8.8, Thm 8.5 | second, separate implementation (Python, from the paper's definitions and tables; letter lengths as variables, branches at b = 2 and 3): the symbolic label states for both parities, 150 distinct obligations each, certified by a third method; concrete runs for b = 2..40 take the same branches; Table 5 reproduced for b = 2..6; negative controls rejected. See `second/README.md` | `second/nest2.py` | A12b |
| Lemma 7.6, Comp. 7.7, Lemma 7.8, Thm A | no closed strand in any tiling, faults included: every pair of supertiles glued along a side (264 cases) and every triple around a vertex (489) allowed by the matching rule, symbolically for every level m >= 1 with certified obligations, and concretely for m = 1..14; the only union with a closed strand, three Γ-supertiles around their vertex 5 (odd m) or 1 (even m), shown impossible from Tables 1 and 3; the nine full compositions have none; unions glued against the signs of the matching rule do have some (negative control) | `faults/faults.py` | A19 |
| Thm 8.5 | b = 1: every ribbon followed in exact arithmetic to level 7 (used in the proof); label computation for b = 1, 2, 3 (corroboration) | `exact/exact.py`, `core/nest.js` | A13, A14 |
| Table 5 | exact strand following through the nest, b = 1..6, to level 9 (b = 1..3 also in exact arithmetic) | `core/hier2.js`, `exact/exact.py` | B05, A13 |
| corroboration | signature, no loops and skeleton period 2 at levels 1-9; skeletons = F(C, parities, omega), built with stand-in lengths of the right parities (not literally S_T(l_1, d_1)) | `core/reduce.js`, `hierarchy/synth.js`, `hierarchy/synthown.js` | B01, B03, B04 |
| corroboration | label inputs rebuilt from (C, parities, omega) equal the exact ones, b = 1..6, to level 9 | `hierarchy/synthnest.js` | B07 |
| §3 (drawing) | the drawn ribbons (hand design in `drawing/engine.js`) realise the port pairing, levels 1-3 | `drawing/checkmodel.js` | B09 |
| Rem. 3.6 | the drawn pieces: containment, the single (transversal) crossing, angles of 45 degrees at the edges | `drawing/drawcheck.py` | B14 |
| App. A (sizes) | tile counts, rim lengths and shortest sides at levels 1-9 from Table 1 and the Fibonacci forms | `hierarchy/sizes.py` | A15 |
| illustration | N_b shares no vertex with the rim of N_{b+2} (b <= 5); edges of N_b on later rims; strands through N_1's tiles | `drawing/nestgap.js`, `nestrim.js`, `onetile.js` | B10-B12 |

## Files

- `core/hier.js`: Tile(1,1), the design's tile tangle, the key-point substitution of the spectre paper (App. A), direct port composition.
- `core/reduce.js`: typed-array composition; extracts the skeleton (marks, runs, partners, parities); the reduced
  walk `rcompose`; canonical encodings.
- `core/nest.js`: label propagation through the nest using the reduced walk (paper §8.2).
- `core/hier2.js`: exact strand following with labels for several nest bases at once.
- `core/tile.js`: prints and checks the tile's pairing.
- `hierarchy/lib.js`: shared loader. `vertices.js`, `combin.js`, `recur.js`: vertices, the pattern C, the matrix M.
- `hierarchy/synth.js`: the skeleton S_T(lambda, d, omega) built from C and lengths alone (function `F`).
- `hierarchy/induction.js`: the 18 skeleton walks of Computation 7.5.
- `hierarchy/synthown.js`, `synthnest.js`: two-level data and label inputs rebuilt from (C, parities, omega).
- `hierarchy/certnest.js`, `certify.py`, `certify_fib.py`: the symbolic label computation and its certificates.
- `hierarchy/letters.py`: letters, recurrence, closed forms; writes `letters.json`.
- `hierarchy/checks.js`: crossover shape and reduced-versus-exact pairing at every level.
- `hierarchy/chains_label.js`: an experiment, not used in any proof: the label computation of Section 8 run along an
  arbitrary chain of supertiles instead of the nest. Agrees with exact strand following on 60 chains up to level 8.
  It gives the evidence of Remark 9.1 (three strands along the chain Θ child 2 of Γ, Γ child 7 of Θ).
- `experiments/three_exact.py`, `experiments/three_label.js` (logs `three_exact.log`, `three_label.log`): the computations
  quoted in Remark 9.1, exact to level 8 and by labels to level 20. Experiments only; no proof uses them, and
  `run_all.sh` does not run them.
- `exact/exact.py`: the second, separate exact implementation.
- `second/nest2.py`: the second, separate implementation of the merging computation (`second/README.md`).
- `faults/faults.py`: Theorem A for every tiling (faults included): the unions of two or three supertiles where they meet. Uses the tables and arithmetic of `second/nest2.py`.
- `referee/`: comparison with Fig. 5.1 (`fig51_compare.py` with the hand encoding `fig51_encoding.json` and
  `gamma_centres.json`; `blobs.py` and `anchor.py` first located the vertex dots on a 400-dpi render of the figure and are
  kept for the record; `fig51_raster.py` redoes this from the PDF), comparison with Fig. 4.1 (`fig41_compare.py` with
  the hand reading `fig41_labels.json`; `fig41_render.py` draws the clusters), overlap check (`overlap.js`).
- `drawing/`: the drawing engine with the hand-drawn design (`engine.js`) and checks that relate the drawing to the
  combinatorial model.
- Generated data (rewritten by stage A): `hierarchy/vertices_*.json`, `combin_8.json`, `M.json`, `letters.json`,
  `certnest_deferred.json`, `exact/exact_C.json`; stage B writes `hierarchy/F_9.json`.

## Provenance

These are frozen copies of the scripts in the development repository, with paths adjusted and some comments brought up to date (no change to the computations), plus `core/tile.js`, `hierarchy/induction.js`, `hierarchy/letters.py`,
`hierarchy/certify_fib.py` and `exact/exact.py`, which were written for the paper. The design is 0.1:01 (`fan21`
grid, spoke digits `01222222222222`). In the programs the sign omega_m of the paper is called `beta`.

## Licence

MIT (`LICENSE`). The paper itself is CC BY 4.0.
